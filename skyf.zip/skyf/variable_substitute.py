import sys
import json
# Read json file and substitute environment specific settings

def buildEnvironmentSettings(filename, build_env, outputfile="src/assets/settings.json"):
    # On the basis of key name; get variables's value
    with open(filename) as fd:
        json_content = json.load(fd)
        try:
          env_json = json_content[build_env]
        except KeyError:
          raise Exception ("Settings for environment {env} not found.".format(env=build_env))
    with open(outputfile, "w") as fp:
        print("Substituted Value of {build_env} to the file : {output_path}"
              .format(build_env=build_env, output_path=outputfile))
        json.dump(env_json, fp, indent=2)

if __name__ == '__main__':
    filepath = sys.argv[1]
    build_env = sys.argv[2]
    try:
        output_path = sys.argv[3]
    except IndexError:
        # Override the file after substitute
        output_path = "src/assets/settings.json"
    buildEnvironmentSettings(filepath, build_env, output_path)
