import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-review',
  templateUrl: './page-review.component.html',
  styleUrls: ['./page-review.component.css']
})
export class PageReviewComponent implements OnInit {

  constructor() { }

  // Not used
  ngOnInit() {
  }

}
