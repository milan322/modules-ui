import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageReviewComponent } from './page-review.component';
import { SkyfBlastModule } from 'skyf.ui.web.components';

describe('PageReviewComponent', () => {
	let component: PageReviewComponent;
	let fixture: ComponentFixture<PageReviewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [SkyfBlastModule],
			declarations: [PageReviewComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		fixture = TestBed.createComponent(PageReviewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
