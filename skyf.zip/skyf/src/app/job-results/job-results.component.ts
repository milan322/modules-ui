import {Component, EventEmitter, OnInit, Output, ViewChild, ViewEncapsulation} from '@angular/core';
import {DatasetComponent} from "../dataset/dataset.component";
import {GridOptions} from "ag-grid-community";
import {ResultsService} from "./services/results.service";
import {MessageService} from "primeng/components/common/messageservice";
import {Message} from "primeng/components/common/api";
import {LoadingService} from "@corteva-research/ngx-components-compat";
import * as moment from 'moment/moment';
import {EditDatasetComponent} from "../datasets-tab/edit-dataset.component";
import {ResultsActionsComponent} from "./results.actions.component";
import {Settings} from "../settings";
import {SettingsService} from "research.web.settings";

@Component({
  selector: 'app-job-results',
  templateUrl: './job-results.component.html',
  styleUrls: ['./job-results.component.css'],
  providers: [ResultsService, MessageService],
  encapsulation: ViewEncapsulation.None
})
export class JobResultsComponent implements OnInit {
  public history_columndefs: any[];
  public history_rowdata: any[];
  public gridApi;
  public historyGridOptions: GridOptions;
  public quickFilterText: any;
  public selectedRowsIds = [];
  msgs: Message[] = [];
  public latestResults;
  public display = false;
  public resultsBlockPopup = false;
  private settings: Settings;
  public blastvizUri;
  public components;
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();
  @ViewChild(DatasetComponent) inputComponent: DatasetComponent;

  constructor(private resultsService: ResultsService,
              private loadingService: LoadingService,
			  private messageService: MessageService,
			  private settingsService: SettingsService) {
	this.settings = settingsService.get<Settings>('_appSettings');
	this.blastvizUri = this.settings.blastvizUri+"/skyfall";
    this.history_columndefs = [
      {
        headerName: "",
        field: "job_id",
        width: 120,
        pinned: 'left',
        suppressFilter: true,
        suppressSorting:true,
        suppressResize: true,
        cellRendererFramework:ResultsActionsComponent
      },
      {
        headerName: "Job Id",
        field: "job_id",
        width: 80,
        sort: "desc"
      },
      {
        headerName: "Job Name",
        field: "job_name",
        width: 150
      },
      {
        headerName: "Created",
        field: "created",
        width: 280,
        suppressMenu : true,
        cellRenderer: this.getDateValue,
        cellRendererParams: {
          inputDate: 'created'
        }
      },
      {
        headerName: "Status",
        field: "status",
		width: 320,
		cellRenderer: this.getStatusText,
		cellRendererParams: {
			status :"status",
			job_id : "job_id"
		}
      },
      {
        headerName: "Expires",
        field: "expiry",
        width: 150,
        suppressMenu : true,
        cellRenderer: this.getDateValue,
        cellRendererParams: {
          inputDate: 'expiry'
        }
      },
      {
        headerName: "Jobdef Id",
        field: "jobdef_id",
        width: 150
      },
      {
        headerName: "Jobdef Name",
        field: "jobdef_name",
        width: 150
      },
      {
        headerName: "Query",
        field: "query",
        width: 150
      },
      {
        headerName: "Database",
        field: "database",
        width: 150
      },
      {
        headerName: "Algorithm",
        field: "algorithm",
        width: 150
      }
    ];

    this.historyGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
        this.gridApi = params.api;
        // this.sortByJobIDDesc();
        this.historyGridOptions.api.sizeColumnsToFit();
      },
      context: {
        componentParent: this,
        componentChild: ResultsActionsComponent
      }
    };
  }

  public callCloseDialog() {
    this.display = false;
    this.latestResults = "";
  }

  public getDateValue(date) {

	if (date == null)
		return ''

	moment.locale();
    const dateFormat = moment.utc(date.value).toDate().toString().split(" ").slice(0, 5).join(" ");
    return '<span>' + dateFormat + '</span>';
    // return '<span>' + moment.utc(date.value).format('MMMM Do YYYY, h:mm:ss a') + '</span>';
  }

  ngOnInit() {
    this.getLatestResults();
  }

  public onFilterTextBoxChanged() {
    this.historyGridOptions.api.setQuickFilter(this.quickFilterText);
  }

  public finalRowsSelected (event) {
    const filteredRows = this.gridApi.getSelectedRows();
    const selectedIdArray = [];
    filteredRows.forEach(function (selectedRow, index) {
      selectedIdArray.push(selectedRow.job_id);
    });
    this.selectedRowsIds = selectedIdArray;
  }

  public sortByJobIDDesc() {
    let sort = [
      {
        colId: "job_id",
        sort: "desc"
      }
    ];
    this.gridApi.setSortModel(sort);
  }

  public getLatestResults () {
    this.loadingService.setMessage("Please wait while getting the latest results...");
    this.resultsService.getData().subscribe((res) => {
      // this.history_rowdata = (<any>res).body;
      /*this.history_rowdata = (<any>res).body.slice(Math.max(res.length - 100, 0)).map(i => {
        return i;
      });*/
      this.history_rowdata = (<any>res).body.slice(-100);
      this.loadingService.clearMessage();
    }, err2 => {
      this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
      this.loadingService.clearMessage();
    });
  }

  public getStatusText(params) {
	//status = "Complete: 113.0/300 Errors: 0";
	let status = params.data.status;
	let job_id = params.data.job_id;
	var index = status.indexOf("Errors");
	if (index == -1)
	  return status;
  
	var error_text =  status.slice(index);	
	var number_errors_array = error_text.split(":");
	var number_errors = Number(number_errors_array[number_errors_array.length-1])
	if (number_errors == 0)
	  return status;
  
	return status.slice(0, index) + '<a href="/error/' + String(job_id) +  '"> ' + error_text + '</a>';
  }
  
  

}
