import { ICellRendererAngularComp } from 'ag-grid-angular';
import { MessageService } from 'primeng/components/common/messageservice';
import {Message} from 'primeng/components/common/api';
import {SharedService} from "../services/shared.service";
import {DatasetService} from "../dataset/services/dataset.service";
import {FormBuilder, FormGroup} from "@angular/forms";
import { Component, Output, EventEmitter, HostListener } from '@angular/core';
import {LoadingService} from "@corteva-research/ngx-components-compat";
import {ResultsService} from "./services/results.service";
import {Settings} from "../settings";
import {SettingsService} from "research.web.settings";

@Component({
  selector: 'app-edit-dataset',
  templateUrl: './job-results.actions.component.html',
  styles: [
    `.btn {
      line-height: 0.5;
      margin-left: 9px
    }`,
    `a {
      cursor: pointer
    }`
  ],
  providers: [MessageService, DatasetService]
})
export class ResultsActionsComponent implements ICellRendererAngularComp {
  public params: any;
  public msgs: Message[] = [];
  private settings: Settings;
  display = false;
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();

  constructor(public sharedService: SharedService,
              private fb: FormBuilder,
              private loadingService: LoadingService,
			  private resultsService: ResultsService,
			  private settingsService: SettingsService) {
				this.settings = settingsService.get<Settings>('_appSettings');
  }

  // called on init
  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

  public doExport($event) {
    this.loadingService.setMessage("Please wait while downloading results...");
    this.msgs = [];
    this.resultsService.getDownloadURL(this.params.data.job_id).subscribe(
      (res: any) => {
        window.open(res.body.psu, "_blank");
        this.params.context.componentParent.messageService.add({severity: 'success', summary: 'Success Message',
          detail: 'Exported successfully.'});
        this.loadingService.clearMessage();
      }, err1 => { if (err1.status == 500) {
        this.params.context.componentParent.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Results Management Service.\n Cannot load result details.',
            detail: 'Message from server: ' + err1.error.message
          });
        } else {
          this.params.context.componentParent.messageService.add({severity: err1.error.status, summary: 'Error Message',
            detail: err1.error.message
          });
        }
        this.loadingService.clearMessage();
      });
  }

  public showResults($event) {
    this.params.context.componentParent.msgs = [];
    this.resultsService.getDownloadURL(this.params.data.job_id).subscribe(
      (res: any) => {
        if (res.body.file_size < (1024 * 1024 * 10)) {
          this.loadingService.setMessage("Please wait while showing results...");
          this.resultsService.callPresignedURL(res.body.psu).subscribe((results: any) => {
            this.params.context.componentParent.display = true;
            this.params.context.componentParent.latestResults = results;
            this.loadingService.clearMessage();
          }, err2 => {
            if (err2.status == 500) {
              this.params.context.componentParent.messageService.add({severity: err2.error.status,
                summary: 'Unhandled error returned from Results Management Service.\n Cannot load results details.',
                detail: 'Message from server: ' + err2.error.message
              });
            } else {
              this.params.context.componentParent.messageService.add({severity: err2.error.status, summary: 'Error Message',
                detail: err2.error.message});
            }
            this.loadingService.clearMessage();
          })
        } else {
          this.params.context.componentParent.resultsBlockPopup = true;
        }
      }, err1 => {
        if (err1.status == 500) {
          this.params.context.componentParent.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Results Management Service.\n Cannot load results details.',
            detail: 'Message from server: ' + err1.error.message
          });
        } else {
          this.params.context.componentParent.messageService.add({severity: err1.error.status, summary: 'Error Message',
            detail: err1.error.message});
        }
        this.loadingService.clearMessage();
      });
  }

  public showBlastVizLink($event) {
	console.log(this.settings);
	let url = this.settings.blastvizUri + "/#/skyfall/"+this.params.data.job_id;
	(window as any).open(url, "_blank");
  }
}
