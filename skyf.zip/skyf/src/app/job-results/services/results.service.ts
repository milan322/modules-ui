import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {isNullOrUndefined} from "util";
import {SharedService} from "../../services/shared.service";
import {Settings} from "../../settings";
import {SettingsService} from "research.web.settings";

@Injectable()
export class ResultsService {

  private settings: Settings;
  public httpOptions;

  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  public getData(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/jobman/api/v1/jobs/history?current=1';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions, observe: 'response' }).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

  public getDownloadURL(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/results/api/v1/jobs';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions, observe: 'response' }).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

  public callPresignedURL(url): Observable<any[]>{
    return this.http.get(url, { headers: this.httpOptions, responseType: 'text' }).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

}
