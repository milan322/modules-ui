import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResearchAuthService } from 'research.auth.client.angular';

@Component({
	template: `<res-login (loginCallback)="login()"></res-login>`
})

export class LoginComponent implements OnInit {

	public login() {
		this.auth.login();
	}

	constructor(private router: Router, private auth: ResearchAuthService) {
	}

	/**
	*  Reads hashed values in the url passed from the IDP.  If successfully reads token,
	   redirects to afterLoginRoute defined in ResearchAuthService
	*/
	ngOnInit() {
		if (this.auth.tryReadStoredToken()) {
			this.router.navigate([this.auth.afterLoginRoute]);
		}
	}

}
