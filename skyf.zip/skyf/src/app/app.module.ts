import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http, XHRBackend, RequestOptions } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {InputTextModule} from 'primeng/inputtext';
import { ResComponentsCoreModule } from '@corteva-research/ngx-components-core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ResComponentsCompatibilityModule } from '@corteva-research/ngx-components-compat';
import { ResearchAuthModule, ResearchAuthGuard, ResearchAuthService } from 'research.auth.client.angular';
import { SettingsModule } from 'research.web.settings';

import { AgGridModule } from 'ag-grid-angular/main';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PageDiagnosticsComponent } from './page-diagnostics/page-diagnostics.component';
import { PageSubmitComponent } from './page-submit/page-submit.component';
import { PageReviewComponent } from './page-review/page-review.component';
import { PageAdminComponent } from './page-admin/page-admin.component';
import { PageHistoryComponent } from './page-history/page-history.component';
import { AdminTabComponent } from './admin-tab/admin-tab.component';
import { TabViewModule } from 'primeng/tabview';
import {SidebarModule} from 'primeng/sidebar';
import { FileUploadModule } from 'primeng/fileupload';
import { DialogModule } from 'primeng/dialog';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DropdownModule} from 'primeng/dropdown';
import {BlockUIModule} from 'primeng/blockui';
import {MessageModule} from 'primeng/message';
import {GrowlModule} from "primeng/growl";
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {FieldsetModule} from 'primeng/fieldset';
import { DatasetsTabComponent } from './datasets-tab/datasets-tab.component';
import { UsersTabComponent } from './users-tab/users-tab.component';
import { LogsTabComponent } from './logs-tab/logs-tab.component';
import { BulkUploadComponent } from './bulk-upload/bulk-upload.component';
import { DatasetComponent } from './dataset/dataset.component';
import { CommonComponent } from './common/common.component';
import {SharedService} from "./services/shared.service";
import {EditDatasetComponent} from "./datasets-tab/edit-dataset.component";
import {AccordionModule} from 'primeng/accordion';
import {CheckboxModule} from 'primeng/checkbox';
import { JobResultsComponent } from './job-results/job-results.component';
import {InputTextareaModule} from 'primeng/inputtextarea';
import { HelpComponent } from './help/help.component';
import { ResultsActionsComponent } from './job-results/results.actions.component';
import {QueryActionsComponent} from "./page-submit/query.actions.component";
import { PersonalDatabaseComponent } from './personal-database/personal-database.component';
import { EditPersonalDatabaseComponent } from "./personal-database/edit-personal-database.component";
import { SkyfErrorPanelModule, SkyfErrorPanelComponent } from "skyf-ui-modules";
import {LicenseManager} from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SHI_International_Corp_-_USA__on_behalf_of_Pioneer_MultiApp_10Devs13_June_2020__MTU5MjAwMjgwMDAwMA==3b3db395a1801a834411462fac496411");

ResearchAuthGuard.loginRoute = '/login';
const routes: Routes = [

  { path: 'diagnostics', component: PageDiagnosticsComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'submit', component: PageSubmitComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'results', component: JobResultsComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'admin', component: PageAdminComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'personalDatabase', component: PersonalDatabaseComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'history', component: PageHistoryComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'home', component: PageSubmitComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
  { path: 'help', component: HelpComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard]},
	{ path: 'login', component: LoginComponent, pathMatch: 'full', canActivate: [ResearchAuthGuard] },
	{ path: 'error/:jobId', component: SkyfErrorPanelComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full'},
  { path: '**', redirectTo: '/login', pathMatch: 'full'},
];

@NgModule({
	declarations: [
		AppComponent,
		HomeComponent,
		LoginComponent,
		PageDiagnosticsComponent,
		PageSubmitComponent,
		PageReviewComponent,
		PageAdminComponent,
		PageHistoryComponent,
		AdminTabComponent,
		DatasetsTabComponent,
		UsersTabComponent,
		LogsTabComponent,
		BulkUploadComponent,
		DatasetComponent,
    EditDatasetComponent,
		CommonComponent,
    JobResultsComponent,
    HelpComponent,
    ResultsActionsComponent,
		QueryActionsComponent,
    PersonalDatabaseComponent,
		EditPersonalDatabaseComponent
	],

	imports: [
		BrowserModule,
    BrowserAnimationsModule,
		FormsModule,
    ReactiveFormsModule,
		HttpModule,
    ResComponentsCoreModule.forRoot(),
    ResComponentsCompatibilityModule.forRoot(),
    HttpClientModule,
		SettingsModule,
		ResearchAuthModule.withDefaultHttpProviders(),
		RouterModule.forRoot(routes, {enableTracing: false}),
    TabViewModule,
    FileUploadModule,
    DialogModule,
    RadioButtonModule,
    DropdownModule,
    MessageModule,
    SidebarModule,
    GrowlModule,
    ConfirmDialogModule,
    FieldsetModule,
    AccordionModule,
    CheckboxModule,
    InputTextareaModule,
    InputTextModule,
    BlockUIModule,
		TabViewModule,
		SkyfErrorPanelModule,
    AgGridModule.withComponents([EditDatasetComponent,
      ResultsActionsComponent,
      QueryActionsComponent,
      EditPersonalDatabaseComponent]),
	],
	exports: [RouterModule],
	providers: [SharedService],
	bootstrap: [AppComponent]
})
export class AppModule { }
