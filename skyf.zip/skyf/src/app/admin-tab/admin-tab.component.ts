import { Component, ViewContainerRef, ViewChildren, QueryList, OnInit, AfterViewInit, ViewEncapsulation  } from '@angular/core';


@Component({
  selector: 'app-admin-tab',
  templateUrl: './admin-tab.component.html',
  styleUrls: ['./admin-tab.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AdminTabComponent implements OnInit {

  public tabsList = ['Datasets', 'Users', 'Logs', 'Bulk Upload'];

  constructor() {

  }

  ngOnInit() {
  }

}
