import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { SkyfBlastModule , DiagnosticsModule} from 'skyf.ui.web.components';
import { PageDiagnosticsComponent } from './page-diagnostics.component';

describe('PageDiagnosticsComponent', () => {
	let component: PageDiagnosticsComponent;
	let fixture: ComponentFixture<PageDiagnosticsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			// imports: [SkyfBlastModule, DiagnosticsModule],
			declarations: [PageDiagnosticsComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		fixture = TestBed.createComponent(PageDiagnosticsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
