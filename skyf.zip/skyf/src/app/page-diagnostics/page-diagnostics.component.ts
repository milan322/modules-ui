import { Component, OnInit } from '@angular/core';
/*import { Service } from 'skyf.ui.web.components';*/

@Component({
	selector: 'app-page-diagnostics',
	templateUrl: './page-diagnostics.component.html',
	styleUrls: ['./page-diagnostics.component.css']
})
export class PageDiagnosticsComponent implements OnInit {

	// service: Service = new Service("This message is from a property of an instance of the 'Service' class defined by sky.ui.web.components intiated from within sky.ui.web");

	constructor() { }

	ngOnInit() {
	}
}
