import { Component, ViewContainerRef, OnInit } from '@angular/core';
import { ResearchAuthService, IdToken, ResearchHttp } from 'research.auth.client.angular';
import { SettingsService } from 'research.web.settings';
import { Settings } from './settings';
import {SharedService} from "./services/shared.service";
import {isNullOrUndefined} from "util";
import {HttpClient, HttpHeaders} from "@angular/common/http";

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
	// Used for modals
	private viewContainerRef: ViewContainerRef;
  versionNumber = require( '../../package.json').version;
	username: string;
	year: number = new Date().getFullYear();
	private settings: Settings;
  public setAuthFlag;
  public rolesList = [];
  public showAdmin = false;

	constructor(private auth: ResearchAuthService,
		private sharedService: SharedService, private httpClient: HttpClient,
		viewContainerRef: ViewContainerRef,
		http: ResearchHttp,
		settingsService: SettingsService) {
		http.onUnathenticatedResponse().subscribe((response) => {
			console.log('401 response', response);
			this.auth.loginWindow();
		});

		this.settings = settingsService.get<Settings>('_appSettings');
		this.setAuthFlag = this.settings.userAuth;
    if (this.setAuthFlag) {
      auth.initialize({
        redirectUri: this.settings.redirectUri,
        afterLoginRoute: '/home',
        afterLogoutRoute: '/login',
        clientId: this.settings.openidClientId,
        scope: 'openid profile',
        openidConfigurationUrl: this.settings.openidConfigurationUrl,
        enableIFrameLogin: true
      });
    } else {
      console.log('Auth is false');
    }

		// You need this small hack in order to catch application root view container ref
		this.viewContainerRef = viewContainerRef;
	}

	public login(): void {
		this.auth.login();
	}

	public logout(): void {
		this.auth.logout();
	}

	ngOnInit(): void {
    this.auth.getUserClaims()
			.subscribe((token: IdToken) => {
        this.username = token.name;
        let globalThis = this;
        const token_obj = JSON.parse(localStorage.getItem('id_token_claims_obj'));
        if (!isNullOrUndefined(token_obj)) {
          this.sharedService.preferredName = token_obj['preferred_username'].split('@')[0];
          const header_obj={'Authorization': 'Bearer '+ localStorage.getItem('access_token')};

		  //this.httpClient.get('https://graph.microsoft.com/v1.0/users/' + token_obj['preferred_username'] + '/memberOf', { headers: new HttpHeaders(header_obj)})
		  // Getting users list of SKYF_ADMIN group.
		  this.httpClient.get('https://graph.microsoft.com/v1.0/groups/ceca61e7-984f-43e6-9a3b-419f210eb7c4/members', { headers: new HttpHeaders(header_obj)})
            .subscribe( (res) => {
              res['value'].forEach(function(roleObj, index) {
				globalThis.rolesList.push(roleObj.displayName);
				if (roleObj.userPrincipalName==token_obj['preferred_username']) {
					globalThis.showAdmin = true;	
				}
              });
            //   if (this.rolesList.indexOf('FPA-Research_Users') <= -1) {
            //     this.auth.logout();
            //   }
            //  if (this.rolesList.indexOf('SKYF_ADMIN') > -1) {
                //this.showAdmin = true;
            //  }
            });
        }
      });
	}

	onNavigate() {
    window.open("https://confluence.phibred.com/display/GS/Skyfall+Support", "_blank");
  }
}
