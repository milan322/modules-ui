import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalDatabaseComponent } from './personal-database.component';

describe('PersonalDatabaseComponent', () => {
  let component: PersonalDatabaseComponent;
  let fixture: ComponentFixture<PersonalDatabaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalDatabaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalDatabaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
