import { ICellRendererAngularComp } from 'ag-grid-angular';
import { MessageService } from 'primeng/components/common/messageservice';
import {Message} from 'primeng/components/common/api';
import {SharedService} from "../services/shared.service";
import { Component, Output, EventEmitter, HostListener } from '@angular/core';
import { PersonalDatabaseService } from "./services/personal-database.service"
import {LoadingService} from "@corteva-research/ngx-components-compat";
import { element } from 'protractor';


@Component({
  selector: 'app-edit-dataset',
  templateUrl: `./edit-personal-database.component.html`,
  styles: [
      `.btn {
      line-height: 0.5;
      margin-left: 9px
    }`,
    `.clickableAwesomeFont {
      cursor: pointer
	}`,
	`.delete-ds-icon {
		margin-left:1px;
	}`
  ],
  providers: [MessageService, PersonalDatabaseService]
})
export class EditPersonalDatabaseComponent implements ICellRendererAngularComp {
  public params: any;
  public msgs: Message[] = [];
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();

  constructor(public sharedService: SharedService,
	public personalDatabaseService: PersonalDatabaseService,
              private messageService: MessageService,
			  private loadingService: LoadingService,
			  //public personaldbcomponent: PersonalDatabaseComponent,
              ) {}

  // called on init
  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

  //@HostListener('click')
  public invokeEdit($event) {
	this.selectedEditEntry.emit([this.params.data.id]);
	this.params.context.componentParent.getDatasetForm(false, this.params.data.id);
  }

  public deleteDataset($event) {
    this.params.context.componentParent.msgs = [];
	this.loadingService.setMessage("Please wait while deleting...");
    this.personalDatabaseService.deleteDataset(this.params.data.id).subscribe(
      (res: any) => {
		if (this.sharedService.all_datasets) {
				this.sharedService.all_datasets.forEach((item, index) => {
					console.log(item.id,index)
					if (item.id == this.params.data.id) {
						this.sharedService.all_datasets.splice(index, 1);		
					}
				});
		}
		   
		console.log(this.sharedService.all_datasets);
        this.personalDatabaseService.getData().subscribe((results: any) => {
          this.params.context.componentParent.sequence_rowdata = results;
          this.params.context.componentParent.messageService.add({severity: 'success', summary: 'Success Message',
			detail: 'Deleted successfully.'});
			this.params.context.componentParent.getPersonalDatabases();
          this.loadingService.clearMessage();
        }, err2 => {
          if (err2.status == 500) {
            this.params.context.componentParent.messageService.add({severity: err2.error.status,
              summary: 'Unhandled error returned from Job Management Service.\n Cannot load sequence details.',
              detail: 'Message from server: ' + err2.error.message
            });
          } else {
            this.params.context.componentParent.messageService.add({severity: err2.error.status, summary: 'Error Message',
              detail: err2.error.message});
          }
          this.loadingService.clearMessage();
        })
      }, err1 => {
        if (err1.status == 500) {
          this.params.context.componentParent.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Job Management Service.\n Cannot load sequence details.',
            detail: 'Message from server: ' + err1.error.message
          });
        } else {
          this.params.context.componentParent.messageService.add({severity: err1.error.status, summary: 'Error Message',
            detail: err1.error.message});
        }
        this.loadingService.clearMessage();
      });
  }
  
}
