import { TestBed, inject } from '@angular/core/testing';

import { PersonalDatabaseService } from './personal-database.service';

describe('PersonalDatabaseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PersonalDatabaseService]
    });
  });

  it('should be created', inject([PersonalDatabaseService], (service: PersonalDatabaseService) => {
    expect(service).toBeTruthy();
  }));
});
