import { Injectable } from '@angular/core';
import {Observable} from "rxjs/Observable";
import {HttpClient} from "@angular/common/http";
import {SettingsService} from "research.web.settings";
import {isNullOrUndefined} from "util";
import {SharedService} from "../../services/shared.service";
import {Settings} from "../../settings";

@Injectable()
export class PersonalDatabaseService {

  private settings: Settings;
  private httpOptions;
  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  // ---------------------------------------------------------------------
  // Getting personal datasets
  // ---------------------------------------------------------------------
  public getData(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions}).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

  public postDataForUpload (fileToUpload): Observable<any> {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets/personal';
    return this.http.post(url, fileToUpload, { headers: this.httpOptions, observe: 'response' });
  }

  // edit work flow.
  public putDataForDataset (fileToUpload): Observable<any> {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets';
    return this.http.put(url, fileToUpload, { headers: this.httpOptions, observe: 'response' });
  }

  public putToUploadURL (url, fileToUpload: File) {
    return this.http.put(url, fileToUpload, { headers: this.httpOptions, observe: 'response' });
  }

  public deleteDataset(data): Observable<any[]>{
    let url = this.settings.apiUri + '/dbman/api/v1/datasets/personal';

	let options = {
		headers: this.httpOptions,
		body: {id: data},
	  };  
    return this.http.delete(url, options).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

}
