import {AfterViewInit, Component, OnInit, ViewEncapsulation} from '@angular/core';
import {ConfirmationService} from "primeng/api";
import {Message} from "primeng/components/common/api";
import {FormBuilder, FormControl, FormGroup} from "@angular/forms";
import {MessageService} from "primeng/components/common/messageservice";
import {SharedService} from "../services/shared.service";
import {GridOptions} from "ag-grid-community";
import {isNullOrUndefined} from "util";
import {PersonalDatabaseService} from "./services/personal-database.service";
import {EditPersonalDatabaseComponent} from "./edit-personal-database.component";
import {LoadingService} from "@corteva-research/ngx-components-compat";
import * as moment from 'moment/moment';

@Component({
  selector: 'app-personal-database',
  templateUrl: './personal-database.component.html',
  styleUrls: ['./personal-database.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [PersonalDatabaseService, MessageService, ConfirmationService],
})
export class PersonalDatabaseComponent implements OnInit {

  personalDatasetForm: FormGroup;
  public buttonLabel = 'Submit Request';
  public buttonDisabled = true;
  public showConfirmDialog = true;
  msgs: Message[] = [];
  public database_columndefs;
  public databaseGridOptions;
  public gridApi;
  public quickFilterText;
  public datasets_rowdata;
  public showPersonalDatasetForm = false;
  public fileToUpload: File = null;

  source: string[] = [];
  public dropDownListAll: any = {
    'source': [{label: 'Public', value: 'Public'},
      {label: 'Internal', value: 'Internal'}],
    'alphabet': [
      //{label: '--Select One--', value: ''},
      {label: 'Protein', value: 'AA'},
      {label: 'Nucleotide', value: 'DNA'}]
  };

  constructor(public fb: FormBuilder,
              public personalDatabaseService: PersonalDatabaseService,
              private messageService: MessageService,
              private confirmationService: ConfirmationService,
              private loadingService: LoadingService,
              public sharedService: SharedService) {
    this.database_columndefs = [
      {
        headerName: "",
        field: "x_did",
        width: 70,
        pinned: 'left',
		cellRendererFramework: EditPersonalDatabaseComponent,
		suppressSizeToFit: true,
		suppressFilter: true,
        suppressSorting:true,
        //suppressResize: true,
      },
      {
        headerName: "Display Name",
        field: "display_name",
        width: 150
      },
      {
        headerName: "Molecule Type",
        field: "alphabet",
        width: 70
	  },
      {
        headerName: "Fasta Name",
        field: "fasta_name",
        width: 150
      },
      {
        headerName: "Created",
        field: "date_created",
        width: 110,
        suppressMenu : true,
        cellRenderer: this.getDateValue,
        cellRendererParams: {
          inputDate: 'created'
        }
      },
      {
        headerName: "Description",
        field: "description",
		width: 150,
		tooltipField: "description"
      },
	  {
        headerName: "Taxonomy ID",
        field: "taxonomy_id",
        width: 100
      }
/*	  

      {
        headerName: "Location",
        field: "location",
        width: 150
      },
      {
        headerName: "Data Classification",
        field: "data_classification",
        width: 150
      },
      {
        headerName: "Root Name",
        field: "root_name",
        width: 150
      },
      {
        headerName: "Indexes Only",
        field: "indexes_only",
        width: 150
      },
      {
        headerName: "Source",
        field: "source",
        width: 120
      },
      {
        headerName: "X DID",
        field: "x_did",
        width: 150
      },
      {
        headerName: "Dataset Type",
        field: "dataset_type",
        width: 150
      },
      {
        headerName: "Enabled",
        field: "enabled",
        width: 150
      },
      {
        headerName: "Security",
        field: "security",
        width: 150,
      },
      {
        headerName: "Sync Schedule",
        field: "sync_schedule",
        width: 150
      },
      {
        headerName: "Update Schedule",
        field: "update_schedule",
        width: 150
      },
      {
        headerName: "X Organism",
        field: "x_organism",
        width: 150
      },
      {
        headerName: "X Other Dset Name",
        field: "x_other_dset_name",
        width: 150
      },
      {
        headerName: "X Other Dset Name Matches",
        field: "x_other_dset_name_matches",
        width: 150
      },
      {
        headerName: "Owner",
        field: "owner",
        width: 150
	  }
*/	  
    ];

    this.databaseGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
        this.gridApi = params.api;
		// this.datasetGridOptions.api.sizeColumnsToFit();
		this.gridApi.sizeColumnsToFit();
      },
      context: {
        componentParent: this
      }
    };
  }

  ngOnInit() {
    this.getPersonalDatabases();
  }

  public getPersonalDatabases () {
    this.loadingService.setMessage("Please wait while getting the latest personal datasets...");
	let owner_name = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'].split('@')[0];
	//let owner_name = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'];
    this.personalDatabaseService.getData().subscribe((res) => {

      this.datasets_rowdata = res.filter(
        data => data.owner === owner_name);
      this.loadingService.clearMessage();
    }, err1 => {
      if (err1.status == 500) {
        this.messageService.add({severity: err1.error.status, summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
          detail: 'Message from server: ' + err1.error.message });
      } else {
        this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      }
      this.loadingService.clearMessage();
    });
  }

  public setDropDown() {
    Object.keys( this.dropDownListAll ).map( dropDownKey => {
      if (this.dropDownListAll[dropDownKey].length === 0) {
        this.dropDownListAll[dropDownKey] = this.sharedService.getDropDownList(dropDownKey);
      }
    });
  }

  public generateDatasetForm (datasetFormObj, editFlow) {
    this.showConfirmDialog = true;
    this.personalDatasetForm = this.fb.group({});

    Object.keys(datasetFormObj).map ( key => {
      this.personalDatasetForm.addControl(key, new FormControl({
          value: datasetFormObj[key].default,
          disabled: datasetFormObj[key].disable
        },
        datasetFormObj[key].validator));
    });
    this.showPersonalDatasetForm = true;
    if (editFlow) {
      this.setDropDown();
    }
    this.personalDatasetForm.updateValueAndValidity();
  }

  // Add Drop Down list options on focus
  public addDropDownList (value) {
    if (this.dropDownListAll[value].length === 0 ) {
      this.dropDownListAll[value] = this.sharedService.getDropDownList(value);
    }
  }

  public submitRequest (value) {
	this.loadingService.setMessage("Please wait while uploading ...");
	this.showConfirmDialog = false;
    this.buttonLabel = 'Submitting...';
    this.buttonDisabled = false;
	let datasetStateObj = this.sharedService.getFormState();

    const file_meta_obj = {};
	if (this.fileToUpload){
		file_meta_obj['filename'] = this.fileToUpload.name;
		file_meta_obj['file_size'] = this.fileToUpload.size;
		file_meta_obj['fileReplace'] = true;
	}else{
		file_meta_obj['fileReplace'] = false;
	}
    Object.keys(datasetStateObj).map(key => {
      file_meta_obj[key] = value[key] || '';
    });

	//file_meta_obj['owner'] = JSON.parse(localStorage.getItem('id_token_claims_obj'))['name'];
	file_meta_obj['contact'] = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'];
    

    if (this.sharedService.personalDatabaseCreateFlow) {
      this.personalDatabaseService.postDataForUpload(file_meta_obj).subscribe(data => {
        this.personalDatabaseService.putToUploadURL((<any>data).body['upload_url'], this.fileToUpload).subscribe(res => {
          this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Saved successfully.'});
		  this.getPersonalDatabases();
		  this.closeSidebar();
        }, err2 => {
          this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
          this.closeSidebar();
        });
      }, err => {
        this.messageService.add({severity: err.error.status, summary: 'Error Message', detail: err.error.message});
        //this.loadingService.clearMessage();
        this.closeSidebar();
      });
    } else {
      this.personalDatabaseService.putDataForDataset(file_meta_obj).subscribe(res => {
		this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Updated successfully.'});
		this.getPersonalDatabases();
        this.closeSidebar();
      },err1 => {
        this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      });
    }
  }

  public closeSidebar () {
	this.loadingService.clearMessage();
    this.showConfirmDialog = false;
    this.sharedService.resetFormObj();
	this.showPersonalDatasetForm = false;
	
  }

  public isValidDatasetInfo () {
    // let datasetValid = this.personalDatasetForm.controls.display_name.value && this.personalDatasetForm.controls.display_name.valid &&
    //   this.personalDatasetForm.controls.contact.value && this.personalDatasetForm.controls.contact.valid &&
    //   // this.datasetForm.controls.owner.value && this.datasetForm.controls.owner.valid &&
    //   this.personalDatasetForm.controls.fasta_name.value && this.personalDatasetForm.controls.fasta_name.valid &&
    //   this.personalDatasetForm.controls.description.value && this.personalDatasetForm.controls.description.valid &&
    //   this.personalDatasetForm.controls.source.value && this.personalDatasetForm.controls.source.valid;

	let datasetValid = this.personalDatasetForm.controls.source.value && this.personalDatasetForm.controls.source.valid &&
	this.personalDatasetForm.controls.alphabet.value && this.personalDatasetForm.controls.alphabet.valid;
	
	if (this.sharedService.personalDatabaseCreateFlow && this.fileToUpload==null) {
		datasetValid = false;
	}
    if ((this.personalDatasetForm.controls.logical_params.value && this.personalDatasetForm.controls.logical_params.invalid) ||
      (this.personalDatasetForm.controls.taxonomy_id.value && this.personalDatasetForm.controls.taxonomy_id.invalid)) {
      return false;
    }
    return datasetValid;
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  uploadFileToActivity() {
    this.loadingService.setMessage("Please wait while uploading ...");
    const file_meta_obj = {'fileUpload': this.fileToUpload,
      'file_size': this.fileToUpload.size,
      'description': this.personalDatasetForm.controls.fileDescription.value,
      'fileReplace': this.personalDatasetForm.controls.fileReplace.value,
      'alphabet': this.personalDatasetForm.controls.uploadAlphabet.value,
    };
    this.personalDatabaseService.postDataForUpload(file_meta_obj).subscribe(data => {
      this.personalDatabaseService.putToUploadURL((<any>data).body['upload_url'], this.fileToUpload).subscribe(res => {
      }, err2 => {
        this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
      });
    }, err => {
      this.messageService.add({severity: err.error.status, summary: 'Error Message', detail: err.error.message});
      this.loadingService.clearMessage();
    });
  }

  public getHidePrompting () {
    if (this.showConfirmDialog) {
      this.confirmationService.confirm({
        message: 'There are unsaved changes. Are you sure you want to continue and discard your changes ?',
        header: 'Please Confirm',
        //icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.sharedService.resetFormObj();
          this.showPersonalDatasetForm = false;
        },
        reject: () => {
          this.showPersonalDatasetForm = true;
        }
      });
    }
  }

  public onFilterTextBoxChanged() {
    this.databaseGridOptions.api.setQuickFilter(this.quickFilterText);
  }

  public getDatasetForm(personalDatabaseCreateFlow, selectedEntryId?) {
    let datasetStateObj;
    this.sharedService.personalDatabaseCreateFlow = personalDatabaseCreateFlow;
    if (isNullOrUndefined(selectedEntryId)) {
      this.sharedService.resetFormObj();
      datasetStateObj = this.sharedService.getFormState();
      this.generateDatasetForm(datasetStateObj, false);
    } else {
		this.loadingService.setMessage("Please wait...");
      datasetStateObj = this.sharedService.getFormState();
      this.personalDatabaseService.getData(selectedEntryId).subscribe(res => {
        const datasetResultObj = res[0];
        Object.keys(datasetStateObj).map(formControl => {
          datasetStateObj[formControl].default = datasetResultObj[formControl] || '';
          datasetStateObj[formControl].disable = false;
        });
		this.generateDatasetForm(datasetStateObj, true);
		this.loadingService.clearMessage();
      }, err1 => {
        if (err1.status == 500) {
          this.messageService.add({severity: err1.error.status, summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
            detail: 'Message from server: ' + err1.error.message});
        } else {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        }
      });
    }
  }

  public getDateValue(date) {

	if (date == null)
		return ''

	moment.locale();
    const dateFormat = moment.utc(date.value).toDate().toString().split(" ").slice(0, 5).join(" ");
    return '<span>' + dateFormat + '</span>';
    // return '<span>' + moment.utc(date.value).format('MMMM Do YYYY, h:mm:ss a') + '</span>';
  }


}
