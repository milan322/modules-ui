import {Validators} from '@angular/forms';

export class DatabaseForm {

  constructor() {}

  public dropDownList = {
    'source': [{label: 'Public', value: 'Public'},
      {label: 'Internal', value: 'Internal'}],
    'alphabet': [
      //{label: '--Select One--', value: ''},
      {label: 'Protein', value: 'P'},
      {label: 'Nucleotide', value: 'N'}],
  };

  public databaseFormObj = {
    'display_name': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'contact': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'owner': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'fasta_name': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'description': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'source': {
      'validator': [Validators.required],
      //'default': 'Public',
      'disable': false,
    },
    'taxonomy_id': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    'alphabet': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    }
  };
}
