import { Injectable } from '@angular/core';
import {DatasetForm} from "../dataset/dataset.form.object";
import {BlastForm} from "../page-submit/blast.form.object";
import {HttpHeaders} from "@angular/common/http"
import {isNullOrUndefined} from "util";

@Injectable()
export class SharedService {

  public showDatasetForm = false;
  public datasetObj = new DatasetForm();
  public blastObj = new BlastForm();
  public createFlow = true;
  public personalDatabaseCreateFlow = true;
  public preferredName;
  public blastDataSets;
  public blastSelectedFile;
  public currentTabSelected = 0;
  public currentAccordianSelected = [true, true, true];
  public filterSession = {};
  public sortSession = {};
  public filterText;
  public rows_displayed_model;
  public all_datasets;
  public datasetButtonLabel = "Show Selected Only";

  constructor() {}

  public showDatasetAddForm () {
    this.showDatasetForm = true;
  }

  public getFormState () {
    return this.datasetObj.datasetFormObj;
  }

  public resetFormObj () {
    this.datasetObj = new DatasetForm();
  }

  public getDropDownList(value) {
    return this.datasetObj.dropDownList[value];
  }

  public setDropDownList(key, value) {
    this.datasetObj.dropDownList[key] = value;
  }

  public getBlastDropDownList(value) {
    return this.blastObj.dropDownList[value];
  }

  public getBlastFormState () {
    return this.blastObj.blastFormObj;
  }

  //this.preferredName
  public getHeaderInfo () {
    const token_obj = JSON.parse(localStorage.getItem('id_token_claims_obj'));
    const token_id = localStorage.getItem('access_token');
    if (!isNullOrUndefined(token_obj) && !isNullOrUndefined(token_id)) {
      const header_obj = {'Content-Type': 'application/json',
        'authentication_token': token_id, 'user_email': token_obj['preferred_username'],
        'X-Identity': this.preferredName, 'email_name': token_obj['name']};
      // return new HttpHeaders({ 'user-info': JSON.stringify(header_obj) })
      return new HttpHeaders(header_obj)
    }

    /*const header_obj={'Content-Type':'application/json',
      'authentication_token':'123','user_email':'radhakrishna.makkenaa@corteva.com',
      'X-Identity':'radhakrishna.makkena','email_name':'Makkenaa, Radhakrishna'};
      // 'X-Identity':'rajasekhar.jangala','email_name':'Jangala,Rajasekhar'};
      //returnnewHttpHeaders({'user-info':JSON.stringify(header_obj)})
    return new HttpHeaders(header_obj)*/
  }

  
/**
 * getRawHeaders
 */
public getRawHeaders() {
	const token_obj = JSON.parse(localStorage.getItem('id_token_claims_obj'));
    const token_id = localStorage.getItem('access_token');
    if (!isNullOrUndefined(token_obj) && !isNullOrUndefined(token_id)) {
      const header_obj = {'Content-Type': 'application/json',
        'authentication_token': token_id, 'user_email': token_obj['preferred_username'],
        'X-Identity': this.preferredName, 'email_name': token_obj['name']};
      // return new HttpHeaders({ 'user-info': JSON.stringify(header_obj) })
      return header_obj
    }
}

}
