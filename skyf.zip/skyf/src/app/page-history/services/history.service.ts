import { Injectable } from '@angular/core';
import {Settings} from "../../settings";
import {isNullOrUndefined} from "util";
import {Observable} from "rxjs/Observable";
import {HttpClient} from "@angular/common/http";
import {SettingsService} from "research.web.settings";
import {HttpHeaders} from '@angular/common/http';
import {SharedService} from "../../services/shared.service";

@Injectable()
export class HistoryService {

  private settings: Settings;
  public httpOptions;

  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    /*this.httpOptions = {
      headers: new HttpHeaders({
        // 'X-Identity': this.sharedService.preferredName
        'X-Identity': 'puneetha.konidala'
    })};*/
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  public getData(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/jobman/api/v1/jobs/history';
    // let url = 'https://skyfapi.sb.research.phibred.com/jobman/api/v1/jobs/history';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions }).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }
}
