import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageHistoryComponent } from './page-history.component';
import { SkyfBlastModule } from 'skyf.ui.web.components';

describe('PageHistoryComponent', () => {
	let component: PageHistoryComponent;
	let fixture: ComponentFixture<PageHistoryComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [SkyfBlastModule],
			declarations: [PageHistoryComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		fixture = TestBed.createComponent(PageHistoryComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
