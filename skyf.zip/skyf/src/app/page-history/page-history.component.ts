import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {GridOptions} from "ag-grid-community";
import {DatasetComponent} from "../dataset/dataset.component";
import {HistoryService} from "./services/history.service";
import {MessageService} from "primeng/components/common/messageservice";
import {Message} from "primeng/components/common/api";
import * as moment from "moment";


@Component({
  selector: 'app-page-history',
  templateUrl: './page-history.component.html',
  styleUrls: ['./page-history.component.css'],
  providers: [HistoryService, MessageService]
})
export class PageHistoryComponent implements OnInit {
  public history_columndefs: any[];
  public history_rowdata: any[];
  public gridApi;
  public historyGridOptions: GridOptions;
  public quickFilterText: any;
  msgs: Message[] = [];
  public components;

  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();
  @ViewChild(DatasetComponent) inputComponent: DatasetComponent;
  
  constructor(private historyService: HistoryService, private messageService: MessageService) {
    this.history_columndefs = [
	  {
        headerName: "Job Id",
        field: "job_id",
        width: 110,
        sort: "desc"
      },
      {
        headerName: "Job Name",
        field: "job_name",
        width: 150
      },
      {
        headerName: "Created",
        field: "created",
        width: 240,
        suppressMenu : true,
        cellRenderer: this.getDateValue,
        cellRendererParams: {
          inputDate: 'created'
        }
      },
      {
        headerName: "Status",
        field: "status",
        width: 280
      },
      {
        headerName: "Jobdef Id",
        field: "jobdef_id",
        width: 150
      },
      {
        headerName: "Jobdef Name",
        field: "jobdef_name",
        width: 150
      },
      {
        headerName: "Query",
        field: "query",
        width: 150
      },
      {
        headerName: "Database",
        field: "database",
        width: 150
      },
      {
        headerName: "Algorithm",
        field: "algorithm",
        width: 150
      }
    ];

    this.historyGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
        this.gridApi = params.api;
        this.historyGridOptions.api.sizeColumnsToFit();
      }
    };
  }
  
  public getDateValue(date) {
    const dateFormat = moment.utc(date.value).toDate().toString().split(" ").slice(0, 5).join(" ");
    return '<span>' + dateFormat + '</span>';
  }
  
  ngOnInit() {
    this.historyService.getData().subscribe((res) => {
      this.history_rowdata = res;
    }, err1 => {
      if (err1.status == 500) {
        this.messageService.add({severity: err1.error.status, summary: 'Unhandled error returned from Job Management Service.\n Cannot load dataset details.',
          detail: 'Message from server: ' + err1.error.message});
      } else {
        this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      }
    });
  }

  public onFilterTextBoxChanged() {
    this.historyGridOptions.api.setQuickFilter(this.quickFilterText);
  }

}
