import {Component, ElementRef, ViewChild, OnInit} from '@angular/core';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
import {LoadingService} from "@corteva-research/ngx-components-compat";
import {Settings} from "../settings";
import {SettingsService} from 'research.web.settings';
import {SharedService} from "../services/shared.service";
import {BulkUploadService} from "./services/bulk-upload.service";

@Component({
  selector: 'app-bulk-upload',
  templateUrl: './bulk-upload.component.html',
  styleUrls: ['./bulk-upload.component.css'],
  providers: [MessageService,BulkUploadService]
})

export class BulkUploadComponent implements OnInit {


  private httpOptions;
  public msgs: Message[] = [];
  public upload_url: string;
  public settings: Settings;
  public fileToUpload: File = null;
  public isValidFileUploaded = true;
  public chooseFileLabel = "Choose CSV file only";

  @ViewChild('bulk_upload_file') bulk_upload_file: ElementRef;

  constructor(private messageService: MessageService,private loadingService: LoadingService, 
	private settingsService: SettingsService, private sharedService: SharedService,public bulkUploadService: BulkUploadService,
	private elementRef:ElementRef) {
    this.settings = settingsService.get<Settings>('_appSettings');	
  }
  
  ngOnInit() {
	this.upload_url = this.settings.apiUri + '/dbman/api/v1/datasets/file';
  }
  
	public onBeforeSend(event) {
		const httpOptions = this.sharedService.getRawHeaders();
		//event.xhr.setRequestHeader('Content-Type', 'multipart/form-data')
		event.xhr.setRequestHeader('authentication_token', httpOptions.authentication_token)
		event.xhr.setRequestHeader('user_email', httpOptions.user_email)
		event.xhr.setRequestHeader('X-Identity', httpOptions["X-Identity"]) 
		event.xhr.setRequestHeader('email_name', httpOptions.email_name)		
	}  
	
  // -----------------------------------------------------------------
  // Placeholder for on upload event. fires once upload is complete
  // -----------------------------------------------------------------
  onUpload(event) {
    this.msgs = [];
    this.msgs.push({severity: 'success', summary: 'Success Message', detail: event.xhr.responseText});
  }
  // Callback for error
  onError(event) {
    // this.messageService.add({severity: 'error', summary: 'Error Message', detail: event.xhr.responseText});
    this.msgs = [];
    this.msgs.push({severity: 'error', summary: 'Error Message', detail: event.xhr.responseText});
  }

  clearViaService() {
    this.messageService.clear();
  }

  clear() {
    this.msgs = [];
  }

  public handleFileInput(files: FileList) {
		this.fileToUpload = files.item(0);
		this.chooseFileLabel = this.fileToUpload.name;
			var size = this.fileToUpload.size;
			if(size < 1 ){
				this.isValidFileUploaded = true;
				this.messageService.add({severity: 'error', summary: 'Error Message', detail: "Empty file uploaded"});
			}else if(this.fileToUpload.type != "application/vnd.ms-excel"){
				this.isValidFileUploaded = true;
				this.messageService.add({severity: 'error', summary: 'Error Message', detail: "Invalid File Format. Please upload CSV file."});
			}else{
				this.isValidFileUploaded = false;
			}
	}

	public uploadFileToActivity() {
		this.loadingService.setMessage("Please wait while uploading ...");
		const file_meta_obj = {'file': this.fileToUpload,
		'file_size': this.fileToUpload.size,
		'file_name': this.fileToUpload.name,
		};
		this.bulkUploadService.postDataForUpload(this.fileToUpload).subscribe(data => { 
			this.loadingService.clearMessage();
			this.messageService.add({severity: 'success', summary: 'Success Message', detail: data.body.message});
		}, 
			err => { 
				this.loadingService.clearMessage();
				this.messageService.add({severity: err.error.status, summary: 'Error Message', detail: err.error.message});
				
		});
	}

}