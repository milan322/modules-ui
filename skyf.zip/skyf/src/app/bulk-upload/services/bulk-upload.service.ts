import { Injectable } from '@angular/core';
import {Settings} from "../../settings";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {SettingsService} from 'research.web.settings';
import {SharedService} from "../../services/shared.service";
import {isNullOrUndefined} from "util";
import { Observable } from 'rxjs';
import { timeout } from 'rxjs/operators';

@Injectable()
export class BulkUploadService {

  private settings: Settings;
  private httpOptions;

  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
	this.httpOptions = this.sharedService.getHeaderInfo();
  }

  public postDataForUpload (fileToUpload?): Observable<any> {

	let url = this.settings.apiUri + '/dbman/api/v1/datasets/file';
	//let url = 'http://10.42.77.145:5000/dbman/api/v1/datasets/file';
	
	return this.http.post(url, fileToUpload, { headers: this.httpOptions, observe: 'response' });
	
  }
}
