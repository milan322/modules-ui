import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageAdminComponent } from './page-admin.component';
import { UiUxModule } from 'skyf.ui.web.components';

describe('PageAdminComponent', () => {
	let component: PageAdminComponent;
	let fixture: ComponentFixture<PageAdminComponent>;
	jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;

	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		TestBed.configureTestingModule({
			imports: [UiUxModule],
			declarations: [PageAdminComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		fixture = TestBed.createComponent(PageAdminComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
