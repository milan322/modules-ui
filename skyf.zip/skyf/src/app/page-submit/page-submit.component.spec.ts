import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { PageSubmitComponent } from './page-submit.component';
import { TreeGridModule, UiUxModule, SkyfBlastModule } from 'skyf.ui.web.components';


describe('PageSubmitComponent', () => {
	let component: PageSubmitComponent;
	let fixture: ComponentFixture<PageSubmitComponent>;

	jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;

	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		TestBed.configureTestingModule({
			imports: [FormsModule, TreeGridModule, UiUxModule, SkyfBlastModule],
			declarations: [PageSubmitComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000 * 60 * 5;
		fixture = TestBed.createComponent(PageSubmitComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
