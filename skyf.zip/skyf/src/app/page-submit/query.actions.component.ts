import { ICellRendererAngularComp } from 'ag-grid-angular';
import { MessageService } from 'primeng/components/common/messageservice';
import {Message} from 'primeng/components/common/api';
import {SharedService} from "../services/shared.service";
import {DatasetService} from "../dataset/services/dataset.service";
import {FormBuilder, FormGroup} from "@angular/forms";
import { Component, Output, EventEmitter, HostListener } from '@angular/core';
import {LoadingService} from "@corteva-research/ngx-components-compat";
import {SubmitService} from "./services/submit.service";

@Component({
  selector: 'app-query-actions',
  template: `
    <span>
        <a title="Delete"
        name='clickableAwesomeFont'
        (click)="deleteSequence($event)"><i class="glyphicon glyphicon-trash"></i></a>
        </span>
  `,
  styles: [
    `.btn {
      line-height: 0.5;
      margin-left: 9px
    }`,
    `a {
      cursor: pointer
    }`
  ],
  providers: [MessageService, DatasetService, SubmitService]
})
export class QueryActionsComponent implements ICellRendererAngularComp {
  public params: any;
  public msgs: Message[] = [];
  display = false;
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();

  constructor(public sharedService: SharedService,
              private fb: FormBuilder,
              private loadingService: LoadingService,
              private submitService: SubmitService) {
  }

  // called on init
  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

  public deleteSequence($event) {
    this.params.context.componentParent.msgs = [];
    this.loadingService.setMessage("Please wait while deleting...");
    this.submitService.deleteQuerySequences(this.params.data.id).subscribe(
      (res: any) => {
        this.submitService.getSequences().subscribe((results: any) => {
          this.params.context.componentParent.sequence_rowdata = results.reverse();
          this.params.context.componentParent.messageService.add({severity: 'success', summary: 'Success Message',
            detail: 'Deleted successfully.'});
          this.loadingService.clearMessage();
        }, err2 => {
          if (err2.status == 500) {
            this.params.context.componentParent.messageService.add({severity: err2.error.status,
              summary: 'Unhandled error returned from Job Management Service.\n Cannot load sequence details.',
              detail: 'Message from server: ' + err2.error.message
            });
          } else {
            this.params.context.componentParent.messageService.add({severity: err2.error.status, summary: 'Error Message',
              detail: err2.error.message});
          }
          this.loadingService.clearMessage();
        })
      }, err1 => {
        if (err1.status == 500) {
          this.params.context.componentParent.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Job Management Service.\n Cannot load sequence details.',
            detail: 'Message from server: ' + err1.error.message
          });
        } else {
          this.params.context.componentParent.messageService.add({severity: err1.error.status, summary: 'Error Message',
            detail: err1.error.message});
        }
        this.loadingService.clearMessage();
      });
  }

}
