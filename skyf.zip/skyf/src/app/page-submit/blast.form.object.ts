import {Validators} from '@angular/forms';

export class BlastForm {

  constructor() {}

  public dropDownList = {
    'algorithm': [{label: 'blastn', value: 'blastn'},
      {label: 'tblastn', value: 'tblastn'},
      {label: 'blastx', value: 'blastx'},
      {label: 'tblastx', value: 'tblastx'},
      {label: 'blastp', value: 'blastp'},
      {label: 'megablast', value: 'megablast'}],
    'expect': [
      {label: 'default', value: 'default'},
      {label: '10.0', value: '10.0'},
      {label: '1e-200', value: '1e-200'},
      {label: '1e-100', value: '1e-100'},
      {label: '1e-75', value: '1e-75'},
      {label: '1e-50', value: '1e-50'},
      {label: '1e-25', value: '1e-25'},
      {label: '0.0001', value: '0.0001'},
      {label: '0.01', value: '0.01'},
      {label: '1.0', value: '1.0'},
      {label: '10.0', value: '10.0'},
      {label: '100.0', value: '100.0'},
      {label: '1000.0', value: '1000.0'}],
    'alignments': [{label: '0', value: '0'},
      {label: '10', value: '10'},
      {label: '50', value: '50'},
      {label: '100', value: '100'},
      {label: '250', value: '250'},
      {label: '500', value: '500'},
      {label: '1000', value: '1000'},
      {label: '1500', value: '1500'},
      {label: '2000', value: '2000'}],
    'descriptions': [{label: '0', value: '0'},
      {label: '10', value: '10'},
      {label: '50', value: '50'},
      {label: '100', value: '100'},
      {label: '250', value: '250'},
      {label: '500', value: '500'},
      {label: '1000', value: '1000'},
      {label: '1500', value: '1500'},
      {label: '2000', value: '2000'}],
    'frequency': [{label: 'Manually', value: 'Manually'},
      {label: 'Daily', value: 'Daily'},
      {label: 'Weekly', value: 'Weekly'},
      {label: 'Monthly', value: 'Monthly'},
      {label: 'Event', value: 'Event'}],
    'output_format': [{label: 'Standard', value: 'Standard'},
      {label: 'Tabular with headers', value: '-outfmt 6'}]
  };

  public blastFormObj = {
    'algorithm': {
      'validator': [Validators.required],
      'default': 'blastn',
      'disable': false,
    },
    'output_format': {
      'validator': [Validators.required],
      'default': 'Standard',
      'disable': false,
    },
    'notification': {
      'validator': [Validators.required],
      'default': '1',
      'disable': false,
    },
    'expect': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'fasta_seq': {
      'validator': [Validators.pattern('^(\n*)[>](\\S)([\\S ]+)\n([\\S \n]+)')],
      'default': '',
      'disable': false,
      // 'validator': [Validators.pattern('^[>\n](\\S)([\\S ]+)\n([\\S \n]+)')],
    },
    'alignments': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'descriptions': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'name': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    'fileDescription': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    /*'persistent': {
      'validator': [Validators.required],
      'default': false,
      'disable': false,
    },*/
    'sequenceDescription': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    /*'seqPersistent': {
      'validator': [Validators.required],
      'default': false,
      'disable': false,
    },*/
    'sequenceName': {
      //'validator': [Validators.pattern('(\\S)*')],
      'default': '',
      'disable': false,
    },
    'fileReplace': {
      'validator': [Validators.required],
      'default': false,
      'disable': false,
    },
    'seqAlphabet': {
      'validator': [],
      'default': 'DNA',
      'disable': false,
    },
    'uploadAlphabet': {
      'validator': [],
      'default': 'DNA',
      'disable': false,
    },
    'lowComplexity': {
      'validator': [],
      'default': 'On',
      'disable': false,
    }
  };
}
