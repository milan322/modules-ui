import { Component, OnInit, ViewEncapsulation, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import {GridOptions, GridReadyEvent} from 'ag-grid-community';
import {DatasetTabService} from "../datasets-tab/services/datasetTab.service";
import {FormBuilder, FormControl, FormGroup} from "@angular/forms";
import {Message} from "primeng/components/common/api";
import {MessageService} from "primeng/components/common/messageservice";
import {SharedService} from "../services/shared.service";
import {ConfirmationService} from "primeng/api";
import {SubmitService} from "./services/submit.service";
import { byteLength } from "byte-length";
import {SettingsService} from "research.web.settings";
import {Settings} from "../settings";
import {isNullOrUndefined} from "util";
import { TimerObservable } from "rxjs/observable/TimerObservable";
import {LoadingService} from "@corteva-research/ngx-components-compat";
import {QueryActionsComponent} from "./query.actions.component";
import * as moment from "moment";


@Component({
	selector: 'app-page-submit',
	templateUrl: './page-submit.component.html',
	styleUrls: ['./page-submit.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [DatasetTabService, MessageService, ConfirmationService, SubmitService]
})

export class PageSubmitComponent implements OnInit {
  public selectedOn: boolean=false;
  public dataset_columndefs: any[];
  public sequence_columndefs: any[];
  public datasetGridOptions: GridOptions;
  public sequenceGridOptions: GridOptions;
  public gridApi;
  public fileGridApi;
  public datasets_rowdata: any[];
  public sequence_rowdata: any[];
  public rowSelection;
  blastForm: FormGroup;
  public buttonLabel = 'Submit Request';
  public buttonDisabled = true;
  public showConfirmDialog = true;
  msgs: Message[] = [];
  public selectedRows;
  public selectedFileEntry;
  public settings: Settings;
  public URL: string;
  public fileToUpload: File = null;
  public sequence_created_id;
  public blastMsg = false;
  public quickFilterText: any;
  public waiting;
  public running;
  public starting;
  public alive;
  public datasetButtonLabel = "Show Selected Only";
  public isValidFileUploaded = false;	
  public selectedRowsCount = 0;
  public selectedFilter='show-all';
  public queryName = "";
  public querynameerror = "";
  public dropDownListAll: any = {
	'algorithm': [{label: 'blastn', value: 'blastn'},
	  {label: 'blastn-short', value: 'blastn-short'},
      {label: 'tblastn', value: 'tblastn'},
      {label: 'blastp', value: 'blastp'},
      {label: 'blastx', value: 'blastx'},
      {label: 'tblastx', value: 'tblastx'},
	  {label: 'megablast', value: 'megablast'}],
    'expect': [
      {label: '10.0', value: '10.0'},
      {label: '1e-200', value: '1e-200'},
      {label: '1e-100', value: '1e-100'},
      {label: '1e-75', value: '1e-75'},
      {label: '1e-50', value: '1e-50'},
      {label: '1e-25', value: '1e-25'},
      {label: '0.0001', value: '0.0001'},
      {label: '0.01', value: '0.01'},
      {label: '1.0', value: '1.0'},
      {label: '10.0', value: '10.0'},
      {label: '100.0', value: '100.0'},
      {label: '1000.0', value: '1000.0'}],
    'alignments': [
      {label: 'default', value: ''},
      {label: '0', value: '0'},
      {label: '10', value: '10'},
      {label: '50', value: '50'},
      {label: '100', value: '100'},
      {label: '250', value: '250'},
      {label: '500', value: '500'},
      {label: '1000', value: '1000'},
      {label: '1500', value: '1500'},
      {label: '2000', value: '2000'}],
    'descriptions': [
      {label: 'default', value: ''},
      {label: '0', value: '0'},
      {label: '10', value: '10'},
      {label: '50', value: '50'},
      {label: '100', value: '100'},
      {label: '250', value: '250'},
      {label: '500', value: '500'},
      {label: '1000', value: '1000'},
      {label: '1500', value: '1500'},
      {label: '2000', value: '2000'}],
    'frequency': [{label: 'Manually', value: 'Manually'},
      {label: 'Daily', value: 'Daily'},
      {label: 'Weekly', value: 'Weekly'},
      {label: 'Monthly', value: 'Monthly'},
      {label: 'Event', value: 'Event'}],
    'output_format': [{label: 'Standard', value: 'Standard'},
      {label: 'Tabular with headers', value: '-outfmt 6'}]
  };
  @ViewChild('file') file: ElementRef;
  constructor(private settingsService: SettingsService,
              private datasetTabService: DatasetTabService,
              public fb: FormBuilder,
              private confirmationService: ConfirmationService,
              public sharedService: SharedService,
              public submitService: SubmitService,
              private loadingService: LoadingService,
              private messageService: MessageService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.alive = true;
    this.dataset_columndefs = [
      {
        headerName: "Display Name",
        field: "display_name",
        width: 150
      },
      {
        headerName: "Owner",
        field: "owner",
        width: 120
      },
      {
        headerName: "Molecule Type",
        field: "alphabet",
        width: 80
      },
      {
        headerName: "Fasta Name",
        field: "fasta_name",
        width: 100
      },
      {
        headerName: "Description",
        field: "description",
        width: 300,
        tooltipField: "description",
      },
      {
        headerName: "Date Last Synched",
        field: "last_sync_updated",
        width: 150,
        suppressMenu : true,
        cellRenderer: function(params) {
          if (params.value) {
            const human_readable_time = moment.unix(parseInt(params.value)).format('LLL');
            // const human_readable_time = moment.unix(parseInt(params.value)).format('MM/DD/YYYY');
            //const human_readable_time = moment(parseInt(params.value), "YYYYMMDD").fromNow();
            return human_readable_time;
          }
        },
      },
      {
        headerName: "Update Frequency",
        field: "update_schedule",
        width: 150
      },
    ];

    this.sequence_columndefs = [
      {
        headerName: "",
        field: "id",
        width: 45,
        pinned: 'left',
        suppressFilter: true,
        suppressSorting:true,
        suppressResize: true,
        cellRendererFramework:QueryActionsComponent
      },
    //   {
    //     headerName: "File Name",
    //     field: "filename",
    //     width: 150
	//   },
	  {
        headerName: "Name",
        field: "name",
		width: 200,
		tooltipField: "name",
      },
      {
        headerName: "Molecule Type",
        field: "alphabet",
        width: 120
      },
      {
        headerName: "File Size (Bytes)",
        field: "file_size",
        width: 125
      },
    //   {
    //     headerName: "Name",
    //     field: "name",
    //     width: 130
    //   },
      {
        headerName: "Description",
        field: "description",
        width: 260,
        tooltipField: "description",
      },
      {
        headerName: "ID",
        field: "id",
        width: 80,
      }
    ];

    this.rowSelection = "multiple";
	
    this.datasetGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
        this.gridApi = params.api;
        this.onRowDataChanged();
		//this.datasetGridOptions.api.sizeColumnsToFit();
		this.gridApi.sizeColumnsToFit();
        // this.gridApi.stopEditing(false);
      },
      context: {
        componentParent: this
      }
    };

    this.sequenceGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
		this.fileGridApi = params.api;
        this.sortBySeqIDDesc();
		// this.sequenceGridOptions.api.sizeColumnsToFit();
		this.fileGridApi.sizeColumnsToFit();
      },
      context: {
        componentParent: this,
        componentChild: QueryActionsComponent
      }
    };
	}

	ngOnInit() {
    TimerObservable.create(0, 30000)
      .takeWhile(() => this.alive)
      .subscribe(() => {
        this.submitService.getJobQueueDepth()
          .subscribe((res) => {
            this.waiting = res['SUM_WAITING'];
            this.running = res['SUM_RUNNING'];
            this.starting = res['SUM_STARTING'];
          }, err2 => {
            if (err2.status == 500) {
              this.messageService.add({severity: err2.error.status,
                summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
                detail: 'Message from server: ' + err2.error.message});
            } else {
              this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
            }
          });
      }, err1 => {
        if (err1.status == 500) {
          this.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
            detail: 'Message from server: ' + err1.error.message});
        } else {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        }
      });

    this.URL = this.settings.apiUri + '/jobman/api/v1/sequences';
    if(this.sharedService.rows_displayed_model) {
      this.datasets_rowdata=[];
      let model=this.sharedService.rows_displayed_model;
      let rowCount=model.getRowCount();
      for(let i=0;i<rowCount;i++) {
        let rowNode=model.getRow(i).data;
        this.datasets_rowdata.push(rowNode);
      }
    } else {
      this.datasetTabService.getfilteredData().subscribe((res) => {
        this.datasets_rowdata = res;
        this.sharedService.all_datasets = res;
      }, err1 => {
        if (err1.status == 500) {
          this.messageService.add({
            severity: err1.error.status,
            summary: 'Unhandled error returned from Job Management Service.\n Cannot load dataset details.',
            detail: 'Message from server: ' + err1.error.message
          });
        } else {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        }
      });
    }

    this.datasetButtonLabel = this.sharedService.datasetButtonLabel;
    this.submitService.getSequences().subscribe((res) => {
	  this.sequence_rowdata = res.reverse();
      //this.sortBySeqIDDesc();
    }, err1 => {
      if (err1.status == 500) {
        this.messageService.add({severity: err1.error.status,
          summary: 'Unhandled error returned from Job Management Service.\n Cannot load dataset details.',
          detail: 'Message from server: ' + err1.error.message});
      } else {
        this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      }
    });
    this.generateBlastForm(this.sharedService.getBlastFormState());
    this.quickFilterText = this.sharedService.filterText;
    if (this.gridApi) {
      this.gridApi.setFilterModel(this.sharedService.filterSession);
      this.gridApi.onFilterChanged();
      this.gridApi.setSortModel(this.sharedService.sortSession);
      this.gridApi.onSortChanged();
      this.gridApi.setQuickFilter(this.sharedService.filterText);
    }
    if(this.datasetGridOptions && this.datasetGridOptions.api) {
      this.datasetGridOptions.api.setQuickFilter(this.sharedService.filterText);
    }
  }

  public getDateValue(date) {
    const dateFormat = moment.utc(date.value).toDate().toString().split(" ").slice(0, 5).join(" ");
    return '<span>' + dateFormat + '</span>';
  }

  
  public showMyDatabases() {	
	this.removeQuickFilter();
	let owner_name = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'].split('@')[0];
	this.datasets_rowdata = this.sharedService.all_datasets;
	this.sharedService.filterSession = this.gridApi.setFilterModel(null);	
	var instance = this.gridApi.getFilterInstance("owner");	
	instance.selectEverything();
	instance.unselectValue('system');
	instance.applyModel();
	this.gridApi.onFilterChanged();
	this.sharedService.filterSession = this.gridApi.getFilterModel();
  }

  public showAllDatabases() {
	this.removeQuickFilter();
	this.gridApi.setFilterModel(null);
	this.datasets_rowdata = this.sharedService.all_datasets;
	//this.onFilterTextBoxChanged();

  }
  public showSelectedDatabases() {
	this.removeQuickFilter();
	let owner_name = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'].split('@')[0];
	this.sharedService.filterSession = this.gridApi.setFilterModel(null);	
	this.datasets_rowdata = this.sharedService.blastDataSets;
	
	var instance = this.gridApi.getFilterInstance("owner");	
    instance.selectNothing();
	instance.selectValue(owner_name);
	instance.selectValue('system');
    instance.applyModel();
	this.gridApi.onFilterChanged();
  }

  public clearAllSelections() {
    this.datasetGridOptions.api.deselectAll();
  }

  public removeQuickFilter() {
	this.quickFilterText = "";
	this.onFilterTextBoxChanged();
  }

  public onSelectionChanged(event) {
	this.selectedRows = this.gridApi.getSelectedRows();
	this.selectedRowsCount = this.gridApi.getSelectedRows().length;
    this.sharedService.blastDataSets = this.selectedRows;
    this.sharedService.filterSession = this.gridApi.getFilterModel();
	this.sharedService.sortSession = this.gridApi.getSortModel();
  }

  // Not using, need to delete this function later
  public restoreAllDatabases() {
	this.datasets_rowdata = this.sharedService.all_datasets;
	let selectedrowIds = [];
	this.sharedService.blastDataSets.forEach(element => {
		  selectedrowIds.push(element.id);
	  });
	
	this.gridApi.forEachNode( (node) => {
		
		if (selectedrowIds.includes(node.data.id)) {
			node.setSelected(true);
		}
	});
  }

  public onViewportChanged() {
	  if (this.selectedFilter=="show-mine") {
		let owner_name = JSON.parse(localStorage.getItem('id_token_claims_obj'))['preferred_username'].split('@')[0];
		var instance = this.gridApi.getFilterInstance("owner");	
		instance.selectEverything();
		instance.unselectValue('system');
		instance.applyModel();
		this.gridApi.onFilterChanged();
	  }
	  
  }
  public onRowDataChanged () {
    let databaseNamesList = [];
    if (this.sharedService && this.sharedService.blastDataSets) {
      this.sharedService.blastDataSets.forEach(function (selectedRow, index) {
        databaseNamesList.push(selectedRow.id);
      });
    }
    if (this.gridApi) {
      if (this.gridApi && databaseNamesList.length > 0) {
        this.datasetGridOptions.api.forEachNode(function (node) {
          if (databaseNamesList.indexOf(node.data.id) > -1) {
            node.setSelected(true);
          }
        });
      }
      this.gridApi.setFilterModel(this.sharedService.filterSession);
      this.gridApi.onFilterChanged();
      this.gridApi.setSortModel(this.sharedService.sortSession);
      this.gridApi.onSortChanged();
      this.gridApi.setQuickFilter(this.sharedService.filterText);
      this.sharedService.rows_displayed_model = this.gridApi.getModel();
    }
  }

  onTabChange(event) {
    this.sharedService.currentTabSelected = event.index;
  }

  onTabOpen(e) {
    this.sharedService.currentAccordianSelected[e.index] = true;
  }

  onTabClose(e) {
    this.sharedService.currentAccordianSelected[e.index] = false;
  }

  // Not using, need to delete this function later
  public toggleDatabases() {
    if (this.selectedOn) {
      this.datasetButtonLabel = "Show Selected Only";
      this.restoreAllDatabases();
    } else {
      this.datasetButtonLabel = "Show All";
      this.showSelectedDatabases();
    }
    this.selectedOn = ! this.selectedOn;
  }


  public clearSequenceData () {
    this.blastForm.controls.fasta_seq.setValue("");
    this.blastForm.controls.sequenceName.setValue("");
    this.blastForm.controls.sequenceDescription.setValue("");
  }

  public isValidSequenceInfo () {
    return this.blastForm.controls.fasta_seq.enabled && this.blastForm.controls.fasta_seq.value &&
      this.blastForm.controls.fasta_seq.valid && this.blastForm.controls.sequenceName.enabled &&
      this.blastForm.controls.sequenceName.valid;
  }

  public isValidFileUpload () {
    return this.fileToUpload.name && !(this.fileToUpload.name.indexOf(' ') > -1);
  }

  
  public queryNameValidation() {
	  if (/\s/.test(this.queryName)) {
		this.querynameerror = "Query Name should not contain spaces";
	  }else{
		this.querynameerror = "";
	  }
	  
  }
  public loadSequence (event) {
    event.stopPropagation();
    this.loadingService.setMessage("Please wait while loading the sequence...");
	let sequenceName = this.blastForm.controls.sequenceName.value;
	let sequenceDescription = this.blastForm.controls.sequenceDescription.value;
    if(sequenceName == ''){
      if(this.blastForm.controls.fasta_seq.value.indexOf(' ') > -1) {
		sequenceName = this.blastForm.controls.fasta_seq.value.split(' ')[0].split('>')[1];
      } else {
        sequenceName = this.blastForm.controls.fasta_seq.value.split('\n')[0].split('>')[1]
      }
	}
	if (sequenceDescription == '') {
		if(this.blastForm.controls.fasta_seq.value.indexOf(' ') > -1) {
			let sequenceDes = this.blastForm.controls.fasta_seq.value.split('\n')[0].split(' ');
			sequenceDescription = sequenceDes.slice(1,sequenceDes.length).join(" ");
		  }
	}
	
    const file_meta_obj = {'fileUpload': sequenceName,
      'description': sequenceDescription,
      'file_size': byteLength(this.blastForm.controls.fasta_seq.value),
      'alphabet': this.blastForm.controls.seqAlphabet.value,
      'fileReplace': true
    };
    this.submitService.postSequenceForUpload(file_meta_obj).subscribe(res1 => {
      let data = (<any>res1).body;
      this.submitService.putSequenceURL(data['upload_url'], this.blastForm.controls.fasta_seq.value).subscribe(res => {
        this.submitService.getSequences().subscribe((res) => {
          this.blastForm.controls.fasta_seq.setValue("");
          this.blastForm.controls.sequenceName.setValue("");
          this.blastForm.controls.sequenceDescription.setValue("");
          this.sequence_rowdata = res.reverse();
		  this.sequence_created_id = data['id'];
		  //this.sortBySeqIDDesc();
		  this.gridApi.refreshCells({ force: true });
		  this.fileRowDataChanged();
          this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Sequence uploaded successfully.'});
          this.sharedService.currentTabSelected = 1;
          this.loadingService.clearMessage();
        }, err2 => {
          this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
          this.loadingService.clearMessage();
        });
      }, err3 => {
        this.messageService.add({severity: err3.error.status, summary: 'Error Message', detail: err3.error.message});
        this.loadingService.clearMessage();
      });
    }, err1 => {
      this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      this.loadingService.clearMessage();
    });
  }

  public sortBySeqIDDesc() {
    let sort = [
      {
        colId: "id",
        sort: "desc"
      }
	];
    if (this.fileGridApi) {
      this.fileGridApi.setSortModel(sort);
    }
  }

  public fileRowDataChanged () {
	this.sequenceGridOptions.api.deselectAll();
    let sequenceList = [];
    if (this.sharedService && this.sharedService.blastSelectedFile) {
      this.sharedService.blastSelectedFile.forEach(function (selectedRow, index) {
        sequenceList.push(selectedRow.filename);
      });
    }
    if (this.fileGridApi && sequenceList.length > 0) {
      this.fileGridApi.forEachNode( function (node1) {
        if (sequenceList.indexOf(node1.data.filename) > -1) {
		  	node1.setSelected(true);
        }
      });
    } else if (!isNullOrUndefined(this.sequence_created_id)) {
		console.log(this.sequence_created_id);
      const globalThis = this;
      this.fileGridApi.forEachNode( function (node1) {
        if (node1.data.id == globalThis.sequence_created_id) {
			node1.setSelected(true);
        }
      });
    }
  }

  public setDropDown() {
    Object.keys( this.dropDownListAll ).map( dropDownKey => {
      if (this.dropDownListAll[dropDownKey].length === 0) {
        this.dropDownListAll[dropDownKey] = this.sharedService.getBlastDropDownList(dropDownKey);
      }
    });
  }

  public generateBlastForm (blastFormObj) {
    this.showConfirmDialog = true;
    this.blastForm = this.fb.group({});

    Object.keys(blastFormObj).map ( key => {
      this.blastForm.addControl(key, new FormControl({
          value: blastFormObj[key].default,
          disabled: blastFormObj[key].disable
        },
        blastFormObj[key].validator));
    });

    this.blastForm.updateValueAndValidity();
  }

  // Add Drop Down list options on focus
  public addDropDownList (value) {
    if (this.dropDownListAll[value].length === 0 ) {
      this.dropDownListAll[value] = this.sharedService.getBlastDropDownList(value);
    }
  }

  public submitBlast (value) {
    if (this.blastForm.controls.fasta_seq.value != "") {
      this.blastMsg = true;
      return false;
    }
    this.showConfirmDialog = false;
    this.buttonLabel = 'Submitting...';
    this.buttonDisabled = false;
    let blastStateObj = this.sharedService.getBlastFormState();
    let databaseList = [];
    this.selectedRows.forEach(function (selectedRow, index) {
      databaseList.push(selectedRow.fasta_name);
    });
    let dataResultObj = {
      "parameters": {
        "algorithm": this.blastForm.controls.algorithm.value,
        "args": ['-evalue', this.blastForm.controls.expect.value,
          '-num_alignments', this.blastForm.controls.alignments.value,
          '-num_descriptions', this.blastForm.controls.descriptions.value,
          '-outfmt', this.blastForm.controls.output_format.value],
        "database": databaseList.join(',')
      },
      "query_source": this.selectedFileEntry[0]['name'],
    };

    Object.keys(blastStateObj).map(key => {
      dataResultObj[key] = value[key] || '';
    });

    if (dataResultObj['lowComplexity'] == 'Off') {
      dataResultObj["parameters"]['args'].push("-dust");
      dataResultObj["parameters"]['args'].push("no");
      dataResultObj["parameters"]['args'].push("-soft_masking");
      dataResultObj["parameters"]['args'].push("false");
    }

    delete dataResultObj["algorithm"];
    delete dataResultObj["alignments"];
    delete dataResultObj["descriptions"];
    delete dataResultObj["expect"];
    delete dataResultObj["fasta_seq"];
    delete dataResultObj["fileDescription"];
    delete dataResultObj["notification"];
    delete dataResultObj["output_format"];
    delete dataResultObj["persistent"];
    delete dataResultObj["replace"];
    delete dataResultObj["seqPersistent"];
    delete dataResultObj["sequenceDescription"];
    delete dataResultObj["sequenceName"];
    delete dataResultObj["owner"];
    const job_name = dataResultObj["name"];
    delete dataResultObj["name"];
    this.submitService.postDataForBlast(dataResultObj).subscribe(res => {
      this.msgs = [];
      this.loadingService.setMessage("Please wait while submitting job...");
      let res1 = <any>res;
      this.submitService.postJobExecution({
        "jobdef_id": res.body['id'],
        "name": job_name
      }).subscribe(job_exec_res => {
        this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Job Submitted: '
          + job_exec_res.body['job_id']});
        this.loadingService.clearMessage();
      }, err1 => {
        if(err1.name && err1.name === 'TimeoutError') {
          this.messageService.add({severity: 'success', summary: 'Success Message',
            detail: 'Job Submitted. The server did not return a jobid (took too long to respond).'});
        } else if (err1.error.status === 504) {
          this.messageService.add({severity: 'success', summary: 'Success Message',
            detail: 'Job Submitted. The server did not return a jobid (took too long to respond).'});
        } else if (err1.status == 500) {
          this.messageService.add({severity: err1.error.status,
            summary: 'Unhandled error returned from Job Management Service.\n Cannot submit blast job.',
            detail: 'Message from server: ' + err1.error.message});
        } else {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        }
        this.loadingService.clearMessage();
      });
    },err2 => {
      if (err2.error.status === 504) {
        this.messageService.add({severity: 'success', summary: 'Success Message',
          detail: 'Job Submitted. The server did not return a jobid (took too long to respond).'});
      } else if (err2.status == 500) {
        this.messageService.add({severity: err2.error.status,
          summary: 'Unhandled error returned from Job Management Service.\n Cannot submit blast job.',
          detail: 'Message from server: ' + err2.error.message});
      } else {
        this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
      }
      this.loadingService.clearMessage();
    });
  }

  public isValidBlastInfo () {
    /*return this.blastForm.controls.fasta_seq.enabled && this.blastForm.controls.fasta_seq.value &&
      this.blastForm.controls.fasta_seq.valid && (this.selectedRows && this.selectedRows.length > 0) &&
      (this.selectedFileEntry && this.selectedFileEntry.length > 0);*/
    return (this.selectedRows && this.selectedRows.length > 0) &&
      (this.selectedFileEntry && this.selectedFileEntry.length > 0);
  }

  public getHidePrompting () {
    if (this.showConfirmDialog) {
      this.confirmationService.confirm({
        message: 'Are you sure that want to navigate away from this page? You will lose all changes made.<br/>' +
        ' Press OK to continue, or Cancel to stay on the current page',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.sharedService.resetFormObj();
          this.sharedService.showDatasetForm = false;
        },
        reject: () => {
          this.sharedService.showDatasetForm = true;
        }
      });
    }
  }


  public onSelectionFileChanged(event) {
    this.selectedFileEntry = this.fileGridApi.getSelectedRows();
    this.sharedService.blastSelectedFile = this.selectedFileEntry
  }

  handleFileInput(files: FileList) {
	this.fileToUpload = files.item(0);
		var size = this.fileToUpload.size;
		if(size < 1){
			this.isValidFileUploaded = true;
			this.messageService.add({severity: 'error', summary: 'Error Message', detail: "Empty file uploaded"});
		}else{
			this.isValidFileUploaded = false;
		}
  }

  uploadFileToActivity() {
    this.loadingService.setMessage("Please wait while uploading ...");
    const file_meta_obj = {'fileUpload': this.fileToUpload,
      'file_size': this.fileToUpload.size,
      'description': this.blastForm.controls.fileDescription.value,
      'fileReplace': this.blastForm.controls.fileReplace.value,
      'alphabet': this.blastForm.controls.uploadAlphabet.value,
    };
    this.submitService.postDataForUpload(file_meta_obj).subscribe(data => {
      this.submitService.putToUploadURL((<any>data).body['upload_url'], this.fileToUpload).subscribe(res => {
        this.submitService.getSequences().subscribe((res) => {
		  this.sequence_rowdata = res.reverse();
		  //this.sortBySeqIDDesc();
		  this.sequence_created_id = res[0].id;
		  this.fileGridApi.refreshCells({ force: true });
		  this.fileRowDataChanged();
          this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'File uploaded successfully.'});
		  this.fileToUpload = null;
		  this.file.nativeElement.value = null;
		  this.loadingService.clearMessage();
		  
        }, err1 => {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        });
      }, err2 => {
        this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
      });
    }, err => {
      this.messageService.add({severity: err.error.status, summary: 'Error Message', detail: err.error.message});
      this.loadingService.clearMessage();
    });
  }

  public onFilterTextBoxChanged() {
    this.datasetGridOptions.api.setQuickFilter(this.quickFilterText);
  }

  ngOnDestroy () {
    try {
      this.alive = false;
      this.sharedService.filterText = this.quickFilterText;
      // This is to take care session saving.
      const formObj = this.sharedService.getBlastFormState();
      const formControls = this.blastForm.controls;

      Object.keys(formObj).map(formControl => {
        if (!isNullOrUndefined(formControls[formControl])) {
          formObj[formControl].default = formControls[formControl].value;
          formObj[formControl].disable = formControls[formControl].disabled;
        }
      });
    } catch (e) {
      console.log('Unable able access form value');
    }
  }

	/*onTreeGridReady(event?: GridReadyEvent, context?: any): void {
		let agent = new HttpAgentXMLHttpRequest();
		let me = context;

		if (Toolbox.isLocalHost())
			me.treeGridOptions.treeGridApi.loadJsonDataString(PageSubmitComponent.JSON_MOCK);
		else
			agent.getJson<any>('https://s3.amazonaws.com/sb-skyf/taxa.json')
				// agent.getJson<any>('http://glassdev.phibred.com:8081/glass/contrib/taxa1.json')
				.then(data => {
					me.treeGridOptions.treeGridApi.loadObject(data);
				})
				.catch(error => {
					// alert(error.message);
					// alert("Loading mocked data due to the prior error.")
					me.treeGridOptions.treeGridApi.loadJsonDataString(PageSubmitComponent.JSON_MOCK);
				})
	}

	onGroupCallback(parentRow: any, childRow: any, scope: any): string {
		if (childRow['name']) {
			let me: PageSubmitComponent = TreeGridComponent.scopeToContext(scope);
			let flatVisual: boolean = (me.treeGridOptions.treeVisualization === enTreeVisualization.NoTreeWithNoCollaspables);

			if (flatVisual) {
				if (childRow['type'] === 'file') {
					if (parentRow)
						return parentRow['name'];
					else
						return me.formatName(childRow['name']);
				} else
					return childRow['name'];
			} else if (childRow['type'] === 'file')
				return "";
			else
				return me.formatName(childRow['name']);
		} else
			return childRow[HelperAgGrid.GROUP_FIELD_NAME];
	}

	private formatName(name: string): string {
		if (name.indexOf("(D) ") == 0 && name.length > 4)
			return name.substring(4);

		return name;
	}

	onTreeVisualizationChanged(newTreeVisualization: enTreeVisualization, context: any): void {
		let me: PageSubmitComponent = context;
		me.treeGridOptions.treeVisualization = newTreeVisualization;
		me._selectedDatasets = {};
	}

	private onGroupIncludeInCountCallback(parentRow: any, childRow: any, scope: any): boolean {
		return childRow['type'] === 'file';
	}

	private onGetTreeGroupImagePathCallback(parentRow: any, childRow: any, scope: any): IOnGetTreeGroupImagePathCallbackResponse {
		let svgPath: string = "";
		let color: string = "#000";

		if (childRow['name'] === '(D) Bacteria') {
			svgPath = "M 6,2.86102e-006L 6,1L 6.98962,1L 7,2.86102e-006L 9,2.86102e-006L 9,1L 10,1L 10,2.86102e-006L 12,2.86102e-006L 12,1L 13,1L 13,2.86102e-006L 14,2.86102e-006L 16,2L 16,5L 14,7L 13,7L 12.9896,6L 12,6L 12,7L 10,7L 10,6L 9,6L 9,7L 7,7L 7,6L 6,6L 6,7L 5,7L 3,5L 2,5L 2,6L 4,8L 11,10L 12,12L 10,14L 2,16L 3,15L 9,13L 10,12L 3,10L 1,8L 0,6L 0,4L 3,2L 5,2.86102e-006L 6,2.86102e-006 Z";
			// color  = "#00ADAD";
		}

		if (childRow['name'] === '(D) Archaea') {
			svgPath = "M 0.559526,2.00695C 0.716009,-1.05238 6.91365,0.878011 11.0937,4.15362C 15.2738,7.42923 15.4377,11 15.6969,13.869C 15.9937,17.1543 9.34277,14.9979 5.1627,11.7223C 0.982634,8.44669 0.406433,5 0.559526,2.00695 Z";
			// color  = "#5B487C";
		}

		if (childRow['name'] === '(D) Eukaryota') {
			svgPath = "M 8.07531,-1.90735e-006C 12.2902,-0.35355 15.4514,1.74846 16,8.57986C 16.3717,13.2087 11.2365,12.2585 8.07531,15.4115C 4.78328,18.6951 -2.59277,10.6406 0.699261,7.35703C 2.8067,5.25502 1.68832,0.535745 8.07531,-1.90735e-006 Z M 5.08058,7.73211C 4.02052,7.73211 3.16117,8.58925 3.16117,9.64658C 3.16117,10.7039 4.02052,11.561 5.08058,11.561C 6.14065,11.561 7,10.7039 7,9.64658C 7,8.58925 6.14065,7.73211 5.08058,7.73211 Z M 8.08058,3C 7.02052,3 6.16116,3.85714 6.16116,4.91447C 6.16116,5.9718 7.02052,6.82893 8.08058,6.82893C 9.14065,6.82893 10,5.9718 10,4.91447C 10,3.85714 9.14065,3 8.08058,3 Z M 11.0806,7.17106C 10.0205,7.17106 9.16117,8.0282 9.16117,9.08553C 9.16117,10.1429 10.0205,11 11.0806,11C 12.1406,11 13,10.1429 13,9.08553C 13,8.0282 12.1406,7.17106 11.0806,7.17106 Z";
			// color  = "#267F00";
		}

		if (svgPath === "")
			return null;

		return {
			color: color,
			svgPath: svgPath
		};
	}

	onTreeGridRowSelect(isSelected: boolean, rowKey: string, rowData: any, context: any): void {
		let me: PageSubmitComponent = context;

		if (rowData['type'] !== 'file')
			return;

		if (isSelected)
			me._selectedDatasets[rowKey] = rowData["name"];
		else if (me._selectedDatasets[rowKey])
			delete me._selectedDatasets[rowKey];
	}

	private buildDatasets(): void {
		this.datasets.splice(0, this.datasets.length);

		for (let dataset of this._avaliableDatasets)
			if (this.filterDatasets == null
				|| this.filterDatasets.length === 0
				|| dataset.toLocaleLowerCase().indexOf(this.filterDatasets.toLocaleLowerCase()) !== -1)
				this.datasets.push(dataset);
	}

	onFilterDatasetsChanged(text: string): void {
		console.log("onFilterDatasetsChanged: " + text);

		this.filterDatasets = text;
		this.buildDatasets();
	}

	private isEnabled(value: IPropertyItemValuePair) : boolean {
		return true;
	}

	onCreateNewJob(): void {

	}

	onCreateNewJobFromTemplate(): void {
		this._popup = enPopup.jobTemplates;
	}

	onCreateNewJobFromPriorJob(): void {
		this._popup = enPopup.priorJobs;
	}

	onCloseModal(event): void {
		this._popup = enPopup.none;
	}

	onJobmanLoadComplete(event) {
		// alert("load complete");
		// this.jobmanOptions.api.resizeAllColumnsToFit();
	}
 */

}

