import { Injectable } from '@angular/core';
import {Settings} from "../../settings";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {SettingsService} from 'research.web.settings';
import {SharedService} from "../../services/shared.service";
import {isNullOrUndefined} from "util";
import { Observable } from 'rxjs';
import { timeout } from 'rxjs/operators';

@Injectable()
export class SubmitService {

  private settings: Settings;
  public httpOptions;

  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  public postDataForBlast (blastInfo?) {
    let url = this.settings.apiUri + '/jobman/api/v1/jobdefs';
    return this.http.post(url, JSON.stringify(blastInfo), { headers: this.httpOptions, observe: 'response' });
  }

  public getSequences (sequences?) {
    let url = this.settings.apiUri + '/jobman/api/v1/sequences';

    if (!isNullOrUndefined(sequences)) {
      url = url + '/' + sequences;
    }

    return this.http.get(url, { headers: this.httpOptions }).map(res => {
      /*return JSON.parse((<any>res)._body).map(item => {
        return item;
      });*/

      return JSON.parse(JSON.stringify(res || null ));
    });
  }

  public postDataForUpload (fileToUpload?): Observable<any> {
    let file_meta  = {
      'filename': fileToUpload.fileUpload.name,
      'file_size': fileToUpload.file_size,
      'description': fileToUpload.description,
      'replace': fileToUpload.fileReplace,
      'alphabet': fileToUpload.alphabet
    };

    let url = this.settings.apiUri + '/jobman/api/v1/sequences';
    return this.http.post(url, file_meta, { headers: this.httpOptions, observe: 'response' });
  }

  public putToUploadURL (url, fileToUpload: File) {
    return this.http.put(url, fileToUpload, { headers: this.httpOptions, observe: 'response' });
  }

  public postSequenceForUpload (fileToUpload?): Observable<any> {
    let file_meta  = {
      'filename': fileToUpload.fileUpload,
      'file_size': fileToUpload.file_size,
      'description': fileToUpload.description,
      'replace': fileToUpload.fileReplace,
      'alphabet': fileToUpload.alphabet
    };

    let url = this.settings.apiUri + '/jobman/api/v1/sequences';
    return this.http.post(url, file_meta, { headers: this.httpOptions, observe: 'response' });
  }

  public putSequenceURL (url, seqStr) {
    return this.http.put(url, seqStr, { headers: this.httpOptions, observe: 'response' });
  }

  public postJobExecution (jobdef_obj): Observable<any> {
    let url = this.settings.apiUri + '/jobexec/api/v1/jobs';
    return this.http.post(url, jobdef_obj, { headers: this.httpOptions, observe: 'response' }).pipe(timeout(20000));
  }

  public getJobQueueDepth (): Observable<any> {
    // https://skyfapi.sb.research.phibred.com/jobexec/api/v1/jobs/queued

    let url = this.settings.apiUri + '/jobexec/api/v1/jobs/queued';

    return this.http.get(url, { headers: this.httpOptions, observe: 'response'}).map((res) =>{
      return res.body;
    });
  }


  public deleteQuerySequences(data): Observable<any[]>{
    let url = this.settings.apiUri + '/jobman/api/v1/sequences';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }
    return this.http.delete(url, { headers: this.httpOptions}).map(res => {
      return JSON.parse(JSON.stringify(res || null ));
    });
  }

}
