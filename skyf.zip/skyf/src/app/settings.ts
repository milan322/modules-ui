export interface Settings {
	aiKey: string;
    openidClientId: string;
    openidConfigurationUrl: string;
    redirectUri: string;
    apiUri: string;
	userAuth: boolean;
	blastvizUri: string;
}
