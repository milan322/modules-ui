import {
  Component, OnInit, ViewChild, ViewEncapsulation, Output, EventEmitter
} from '@angular/core';
import { GridOptions } from 'ag-grid-community/main';
import {DatasetTabService} from "./services/datasetTab.service";
import {SharedService} from "../services/shared.service";
import {EditDatasetComponent} from "./edit-dataset.component";
import {DatasetComponent} from "../dataset/dataset.component";
import {MessageService} from "primeng/components/common/messageservice";
import {Message} from "primeng/components/common/api";
import {isNullOrUndefined} from "util";

@Component({
  selector: 'app-datasets-tab',
  templateUrl: './datasets-tab.component.html',
  styleUrls: ['./datasets-tab.component.css'],
  providers: [DatasetTabService, MessageService],
  encapsulation: ViewEncapsulation.None
})
export class DatasetsTabComponent implements OnInit {

  public dataset_columndefs: any[];
  public datasets_rowdata: any[];
  public gridApi;
  public datasetGridOptions: GridOptions;
  public quickFilterText: any;
  msgs: Message[] = [];

  public components;
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();
  @ViewChild(DatasetComponent) inputComponent: DatasetComponent;

  constructor(private datasetTabService: DatasetTabService,
              private messageService: MessageService,
              public sharedService: SharedService) {
    this.dataset_columndefs = [
      {
        headerName: "",
        field: "x_did",
        width: 70,
        pinned: 'left',
        cellRendererFramework: EditDatasetComponent
      },
      {
        headerName: "Fasta Name",
        field: "fasta_name",
        width: 150
      },
      {
        headerName: "Taxonomy ID",
        field: "taxonomy_id",
        width: 150
      },
      {
        headerName: "Location",
        field: "location",
        width: 150
      },
      {
        headerName: "Data Classification",
        field: "data_classification",
        width: 150
      },
      {
        headerName: "Description",
        field: "description",
		width: 150,
		tooltipField: "description"
      },
      {
        headerName: "Root Name",
        field: "root_name",
        width: 150
      },
      {
        headerName: "Indexes Only",
        field: "indexes_only",
        width: 150
      },
      {
        headerName: "Source",
        field: "source",
        width: 120
      },
      {
        headerName: "Upload Status",
        field: "upload_status",
        width: 150
      },
      {
        headerName: "Display Name",
        field: "display_name",
        width: 150
      },
      {
        headerName: "Dataset Type",
        field: "dataset_type",
        width: 150
      },
      {
        headerName: "Molecule Type",
        field: "alphabet",
        width: 150
      },
      {
        headerName: "Created",
        field: "created",
        width: 150
      },
      {
        headerName: "Enabled",
        field: "enabled",
        width: 150
      },
      {
        headerName: "Security",
        field: "security",
        width: 150,
      },
      {
        headerName: "Sync Schedule",
        field: "sync_schedule",
        width: 150
      },
      {
        headerName: "Update Schedule",
        field: "update_schedule",
        width: 150
      },
    //   {
    //     headerName: "X Organism",
    //     field: "x_organism",
    //     width: 150
    //   },
    //   {
    //     headerName: "X Other Dset Name",
    //     field: "x_other_dset_name",
    //     width: 150
    //   },
    //   {
    //     headerName: "X Other Dset Name Matches",
    //     field: "x_other_dset_name_matches",
    //     width: 150
    //   },
      {
        headerName: "Owner",
        field: "owner",
        width: 150
      }
    ];

    this.datasetGridOptions = <GridOptions>{
      enableFilter: true,
      onGridReady: (params) => {
        this.gridApi = params.api;
        // this.datasetGridOptions.api.sizeColumnsToFit();
      },
      context: {
        componentParent: this
      }
    };
  }

  ngOnInit() {
	  this.getAdminDatabases();
  }

  public getAdminDatabases(){
	this.datasetTabService.getData().subscribe((res) => {
		this.datasets_rowdata = res;
	  }, err1 => {
		if (err1.status == 500) {
		  this.messageService.add({severity: err1.error.status, summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
			detail: 'Message from server: ' + err1.error.message });
		} else {
		  this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
		}
	  });
  }
  public onFilterTextBoxChanged() {
    this.datasetGridOptions.api.setQuickFilter(this.quickFilterText);
  }

  public getDatasetForm(createFlow, selectedEntryId?) {
    let datasetStateObj;
    this.sharedService.createFlow = createFlow;
    if (isNullOrUndefined(selectedEntryId)) {
      this.sharedService.resetFormObj();
      datasetStateObj = this.sharedService.getFormState();
      this.inputComponent.generateDatasetForm(datasetStateObj, false);
    } else {
      datasetStateObj = this.sharedService.getFormState();
      this.datasetTabService.getData(selectedEntryId).subscribe(res => {
        const datasetResultObj = res[0];
        Object.keys(datasetStateObj).map(formControl => {
          datasetStateObj[formControl].default = datasetResultObj[formControl] || '';
          datasetStateObj[formControl].disable = false;
        });
        this.inputComponent.generateDatasetForm(datasetStateObj, true);
      }, err1 => {
        if (err1.status == 500) {
          this.messageService.add({severity: err1.error.status, summary: 'Unhandled error returned from Dataset Management Service.\n Cannot load dataset details.',
            detail: 'Message from server: ' + err1.error.message});
        } else {
          this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
        }
      });
    }
  }

}
