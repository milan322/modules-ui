import { ICellRendererAngularComp } from 'ag-grid-angular';
import {isNullOrUndefined} from 'util';
import {ConfirmationService} from 'primeng/primeng';
import { MessageService } from 'primeng/components/common/messageservice';
import {Message} from 'primeng/components/common/api';
import {SharedService} from "../services/shared.service";
import {DatasetTabService} from "./services/datasetTab.service";
import {DatasetComponent} from "../dataset/dataset.component";
import {DatasetService} from "../dataset/services/dataset.service";
import {FormBuilder, FormGroup} from "@angular/forms";
import { Component, Output, EventEmitter, HostListener } from '@angular/core';

@Component({
  selector: 'app-edit-dataset',
  template: `<a title="Edit Dataset" 
                id='clickableAwesomeFont'
                (click)="invokeEdit($event)"><i class="fa fa-edit"></i></a>`,
  styles: [
      `.btn {
      line-height: 0.5;
      margin-left: 9px
    }`,
    `#clickableAwesomeFont {
      cursor: pointer
    }`
  ],
  providers: [MessageService, DatasetTabService, DatasetService]
})
export class EditDatasetComponent implements ICellRendererAngularComp {
  public params: any;
  public msgs: Message[] = [];
  datasetForm: FormGroup;
  @Output() selectedEditEntry: EventEmitter <any> = new EventEmitter<any>();

  constructor(public sharedService: SharedService,
              private fb: FormBuilder,
              private datasetService: DatasetService,
              public datasetTabService: DatasetTabService,
              private messageService: MessageService) {
  }

  // called on init
  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

  @HostListener('click')
  public invokeEdit($event) {
    this.selectedEditEntry.emit([this.params.data.id]);
    this.params.context.componentParent.getDatasetForm(false, this.params.data.id);
  }
}
