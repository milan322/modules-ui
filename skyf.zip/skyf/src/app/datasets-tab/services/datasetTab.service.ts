import { Injectable } from '@angular/core';
import { Settings } from './../../settings';
import { SettingsService } from 'research.web.settings';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {isNullOrUndefined} from 'util';
import {SharedService} from "../../services/shared.service";

@Injectable()
export class DatasetTabService {

  private settings: Settings;
  private httpOptions;
  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  // ---------------------------------------------------------------------
  // Getting dataset manager data
  // ---------------------------------------------------------------------
  public getfilteredData(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets';

    if (!isNullOrUndefined(data)) {
      url = url + '/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions}).map(res => {
      /*return JSON.parse((<any>res)._body).map(item => {
        return item;
      });*/

      return JSON.parse(JSON.stringify(res || null ));
    });
  }

  // ---------------------------------------------------------------------
  // Getting dataset manager data
  // ---------------------------------------------------------------------
  public getData(data?): Observable<any[]> {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets?unfiltered=1';

    if (!isNullOrUndefined(data)) {
      url = this.settings.apiUri + '/dbman/api/v1/datasets/' + data;
    }

    return this.http.get(url, { headers: this.httpOptions}).map(res => {
      /*return JSON.parse((<any>res)._body).map(item => {
        return item;
      });*/

      return JSON.parse(JSON.stringify(res || null ));
    });
  }  

}
