import { TestBed, inject } from '@angular/core/testing';

import { DatasetTabService } from './datasetTab.service';

describe('DatasetService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DatasetTabService]
    });
  });

  it('should be created', inject([DatasetTabService], (service: DatasetTabService) => {
    expect(service).toBeTruthy();
  }));
});
