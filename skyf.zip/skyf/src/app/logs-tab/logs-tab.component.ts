import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logs-tab',
  templateUrl: './logs-tab.component.html',
  styleUrls: ['./logs-tab.component.css']
})
export class LogsTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
