import {Validators} from '@angular/forms';

export class DatasetForm {

  constructor() {}

  public dropDownList = {
    'source': [{label: 'Public', value: 'Public'},
      {label: 'Internal', value: 'Internal'}],
    'alphabet': [
      //{label: '--Select One--', value: ''},
      {label: 'Protein', value: 'P'},
      {label: 'Nucleotide', value: 'N'}],
    'type': [{label: 'Logical', value: 'LOGICAL'},
      {label: 'Transient', value: 'TRANS'},
      {label: 'Static', value: 'STATIC'},
      {label: 'Synched', value: 'SYNC'}],
    'update_schedule': [{label: '30', value: '30'},
      {label: '40', value: '40'},
      {label: '60', value: '60'},
      {label: '100', value: '100'}]
  };

  public datasetFormObj = {
    'display_name': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'contact': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'owner': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'source_location': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'source_spec': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'scope': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'root_name': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'fasta_name': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'id': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'description': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'num_seqs': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    'post_process': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    'data_classification': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'enabled': {
      'validator': [Validators.required],
      'default': '1',
      'disable': false,
    },
    'indexes_only': {
      'validator': [Validators.required],
      'default': '1',
      'disable': false,
    },
    'location': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'logical_params': {
      'validator': [],
      'default': '',
      'disable': false,
    },
    'source': {
      'validator': [Validators.required],
      //'default': 'Public',
      'disable': false,
    },
    'type': {
      'validator': [Validators.required],
      //'default': 'LOGICAL',
      'disable': false,
    },
    'taxonomy_id': {
      'validator': [],
      'default': '0',
      'disable': false,
    },
    'update_schedule': {
      'validator': [Validators.required],
      'default': '30',
      'disable': false,
    },
    'url': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'last_sync_status': {
      'validator': [Validators.required],
      'default': '',
      'disable': false,
    },
    'alphabet': {
      'validator': [Validators.required],
      //'default': '',
      'disable': false,
	},
	'protocol': {
		'validator': [Validators.required],
		//'default': 'HTTP',
		'disable': false,
	  }
	
  };
}
