import { Injectable } from '@angular/core';
import { Settings } from '../../settings';
import {SettingsService} from 'research.web.settings';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {SharedService} from "../../services/shared.service";

@Injectable()
export class DatasetService {

  private settings: Settings;
  private httpOptions;

  constructor(private http: HttpClient, private settingsService: SettingsService, private sharedService: SharedService) {
    this.settings = settingsService.get<Settings>('_appSettings');
    this.httpOptions = this.sharedService.getHeaderInfo();
  }

  // create flow save
  public postDataForDataset (data) {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets';
    //let url = 'https://skyfapi.sb.research.phibred.com/dbman/api/v1/datasets';
    return this.http.post(url, JSON.stringify(data), { headers: this.httpOptions, observe: 'response' });
  }

  // update flow save
  public putDataForDataset (data) {
    let url = this.settings.apiUri + '/dbman/api/v1/datasets';
    //let url = 'https://skyfapi.sb.research.phibred.com/dbman/api/v1/datasets';
    return this.http.put(url, JSON.stringify(data), { headers: this.httpOptions, observe: 'response' });
  }

}
