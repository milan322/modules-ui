import {Component, OnInit, ViewEncapsulation, AfterViewInit, Output, EventEmitter} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {DatasetService} from "./services/dataset.service";
import {SharedService} from "../services/shared.service";
import { Message } from 'primeng/components/common/api';
import {ConfirmationService} from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-dataset',
  templateUrl: './dataset.component.html',
  styleUrls: ['./dataset.component.css'],
  providers: [DatasetService, MessageService, ConfirmationService],
  encapsulation: ViewEncapsulation.None
})
export class DatasetComponent implements OnInit, AfterViewInit {

  datasetForm: FormGroup;
  public buttonLabel = 'Submit Request';
  public buttonDisabled = true;
  public showConfirmDialog = true;
  msgs: Message[] = [];
  source: string[] = [];

  @Output() blur = new EventEmitter<string>();
  public dropDownListAll: any = {
    'source': [
		{label: 'Public', value: 'Public'},
		{label: 'Internal', value: 'Internal'}
	],

    'alphabet': [
      	{label: 'Protein', value: 'AA'},
		{label: 'Nucleotide', value: 'DNA'}
	],

	'type': [
		{label: 'Logical', value: 'LOGICAL'},
		{label: 'Physical', value: 'PHYSICAL'},
	],

    'update_schedule': [
		{label: 'Static', value: 'STATIC'},
      	{label: 'Weekly', value: 'WEEKLY'},
      	{label: 'Monthly', value: 'MONTHLY'},
		{label: 'Quarterly', value: 'QUARTERLY'}
	],
	'protocol': [
		{label: 'HTTP', value: 'HTTP'},
		{label: 'HTTPS', value: 'HTTPS'},
		{label: 'FTP', value: 'FTP'},
		{label: 'SFTP', value: 'SFTP'},
		{label: 'LOCAL', value: 'LOCAL'}
	]
  };

  constructor(public fb: FormBuilder,
              public datasetService: DatasetService,
              private messageService: MessageService,
              private confirmationService: ConfirmationService,
			  public sharedService: SharedService) {
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

  public setDropDown() {
    Object.keys( this.dropDownListAll ).map( dropDownKey => {
      if (this.dropDownListAll[dropDownKey].length === 0) {
        this.dropDownListAll[dropDownKey] = this.sharedService.getDropDownList(dropDownKey);
      }
    });
  }

  public generateDatasetForm (datasetFormObj, editFlow) {
    this.showConfirmDialog = true;
    this.datasetForm = this.fb.group({});

    Object.keys(datasetFormObj).map ( key => {
      this.datasetForm.addControl(key, new FormControl({
          value: datasetFormObj[key].default,
          disabled: datasetFormObj[key].disable
        },
        datasetFormObj[key].validator));
    });
    this.sharedService.showDatasetForm = true;
    if (editFlow) {
      this.setDropDown();
    }
    this.datasetForm.updateValueAndValidity();
  }

  // Add Drop Down list options on focus
  public addDropDownList (value) {
    if (this.dropDownListAll[value].length === 0 ) {
      this.dropDownListAll[value] = this.sharedService.getDropDownList(value);
    }
  }
 
  public submitRequest (value) {
    this.showConfirmDialog = false;
    this.buttonLabel = 'Submitting...';
    this.buttonDisabled = false;
    let datasetStateObj = this.sharedService.getFormState();
    let dataResultObj = {};
    Object.keys(datasetStateObj).map(key => {
      dataResultObj[key] = value[key] || '';
    });
    if (this.sharedService.createFlow) {
      this.datasetService.postDataForDataset(dataResultObj).subscribe(res => {
        let res1 = <any>res;
		this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Saved successfully.'});
		this.blur.next();
        this.closeSidebar();
      },err2 => {
        this.messageService.add({severity: err2.error.status, summary: 'Error Message', detail: err2.error.message});
      });
    } else {
      this.datasetService.putDataForDataset(dataResultObj).subscribe(res => {
        let res1 = <any>res;
		this.messageService.add({severity: 'success', summary: 'Success Message', detail: 'Updated successfully.'});
		this.blur.next();
        this.closeSidebar();
      },err1 => {
        this.messageService.add({severity: err1.error.status, summary: 'Error Message', detail: err1.error.message});
      });
    }

  }

  public closeSidebar () {
    this.showConfirmDialog = false;
    this.sharedService.resetFormObj();
    this.sharedService.showDatasetForm = false;
  }

  public isValidDatasetInfo () {
    let datasetValid = this.datasetForm.controls.display_name.value && this.datasetForm.controls.display_name.valid &&
      
      this.datasetForm.controls.source_location.value && this.datasetForm.controls.source_location.valid &&
      this.datasetForm.controls.source_spec.value && this.datasetForm.controls.source_spec.valid &&
      
      this.datasetForm.controls.fasta_name.value && this.datasetForm.controls.fasta_name.valid &&
      
	  this.datasetForm.controls.source.value && this.datasetForm.controls.source.valid &&
	  this.datasetForm.controls.type.value && this.datasetForm.controls.type.valid &&
	  this.datasetForm.controls.update_schedule.value && this.datasetForm.controls.update_schedule.valid &&
	  this.datasetForm.controls.protocol.value && this.datasetForm.controls.protocol.valid;

    return datasetValid;
  }

  public getHidePrompting () {
    if (this.showConfirmDialog) {
      this.confirmationService.confirm({
        message: 'There are unsaved changes. Are you sure you want to continue and discard your changes ?',
        header: 'Please Confirm',
        accept: () => {
          this.sharedService.resetFormObj();
          this.sharedService.showDatasetForm = false;
        },
        reject: () => {
          this.sharedService.showDatasetForm = true;
        }
      });
    }
  }
}
