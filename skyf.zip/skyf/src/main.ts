import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { enableProdMode } from '@angular/core';
import { environment } from './environments/environment';
import { SettingsLoader, LoaderSettings } from 'research.web.settings';
import { MetricsService } from 'research.web.metrics';
import { Settings } from './app/settings';

import { AppModule } from './app/app.module';


if (environment.production) {
	// enableProdMode();
}

const settings: LoaderSettings = { file: 'assets/settings.json', variable: '_appSettings' };
const loader = new SettingsLoader(settings);
loader.readTextFile()
	.then((settingsJson: string) => {
		const appSettings = <Settings>JSON.parse(settingsJson);
		if (window.location.host.indexOf('localhost') === -1) {
			MetricsService.start(appSettings.aiKey);
		}
	})
	.catch(() => { })
	.then(() => platformBrowserDynamic().bootstrapModule(AppModule));
