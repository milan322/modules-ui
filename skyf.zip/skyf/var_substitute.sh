#!/usr/bin/env bash
echo "Running to substitute variables"
python3 variable_substitute.py $1 $2 $3

