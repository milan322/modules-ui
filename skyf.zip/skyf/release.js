var semver = require('semver');
var fs = require('fs');
var package = require('./package.json');


function jumpVersion() {
  VERSION = package.version;
  NEXT_VERSION=semver.inc(VERSION, 'patch', 1);
  var j = package;
  j.version = NEXT_VERSION;
  var s = JSON.stringify(j, null, 2);
  fs.writeFileSync('package.json', s);
  console.log(NEXT_VERSION);
  return NEXT_VERSION;
}

return jumpVersion();
